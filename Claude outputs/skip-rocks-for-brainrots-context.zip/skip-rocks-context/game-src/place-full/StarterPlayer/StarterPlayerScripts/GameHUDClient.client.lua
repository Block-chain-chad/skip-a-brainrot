--[[ ==========================================================================
GameHUDClient -- the new HUD shell: 1350x775 canvas, currency cluster, left
nav rail (v2, moved 2026-07-30 per user decision), panel host + registration
protocol, legacy retirements, ESC.
---------------------------------------------------------------------------
This is the integration point five later tasks build against. The contract:

	ctx = {
		Tokens, Builders,        -- ReplicatedStorage.Modules.UIKit, straight through
		remotes,                 -- ReplicatedStorage.Remotes
		host,                    -- Frame every panel module parents its own panel into
		openPanel(id),           -- show/build the panel registered under `id`
		closePanel(),            -- close whatever panel is open
		setBadge(id, n),         -- notification badge on the matching rail item
		pillAnchor(which),       -- "coin"|"gem" -> Vector2 screen position of that
		                         -- pill (Task 7 uses this for reward-fly targets)
		state,                   -- shared client state table, kit README section 5
	}

Panel registration: every ModuleScript dropped into the sibling GameHUDPanels
folder is required at startup and must return { Id = "bag", Build = function(ctx)
-> Frame }. A module with no Build/Id, or a require() that errors, is skipped
silently -- panels arrive in later tasks, GameHUDPanels is empty right now.

All geometry below is offset px against the 1350x775 design canvas (kit
README section 1), scaled uniformly by ONE UIScale/fit() pair -- every other
HUD element hangs off the same `root` Frame so nothing needs its own resize
listener.
========================================================================== ]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local GuiService = game:GetService("GuiService") -- Bug B fix: GetGuiInset() compensation, see Canvas below
local TextService = game:GetService("TextService") -- Bug A fix: measures pill text width, see buildPill below

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local remotes = ReplicatedStorage:WaitForChild("Remotes")
local modules = ReplicatedStorage:WaitForChild("Modules")

local UIKit = modules:WaitForChild("UIKit")
local T = require(UIKit:WaitForChild("Tokens"))
local UI = require(UIKit:WaitForChild("Builders"))
local SideRail = require(modules:WaitForChild("SideRail"))
-- The six rail buttons are raw Instance.new TextButtons: they bypass every
-- styled constructor, so they were silent. Same SfxWired attribute key the
-- constructors use, so a control that is BOTH built here and styled elsewhere
-- can still only ever get one connection -- no double clicks.
local SoundKit = require(modules:WaitForChild("SoundKit"))
-- Fetch the whole sound set once, at join. PreloadAsync yields inside SoundKit's
-- own task.spawn, so this never blocks the HUD build.
task.spawn(function() pcall(SoundKit.preload) end)
local CLICK_VOLUME = 0.12
local function wireClick(btn, soundName)
	if btn:GetAttribute("SfxWired") then return end
	btn:SetAttribute("SfxWired", true)
	btn.MouseButton1Click:Connect(function()
		pcall(SoundKit.play, soundName or "uiClick", nil, { volume = CLICK_VOLUME })
	end)
end
-- The kit's nav icons, redrawn from GUI primitives (see UIKit.IconArt) for as
-- long as Tokens.icons is empty. pcall'd on purpose: a missing or broken
-- IconArt must not take the whole HUD down with it -- the rail just falls back
-- to its emoji stand-in.
local okIconArt, IconArt = pcall(function()
	return require(UIKit:WaitForChild("IconArt", 5))
end)
if not okIconArt then IconArt = nil end

---------------------------------------------------------------- canvas
local gui = Instance.new("ScreenGui")
gui.Name = "GameHUD"
gui.IgnoreGuiInset = true
gui.ResetOnSpawn = false
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.DisplayOrder = 7
gui.Parent = playerGui

local root = Instance.new("Frame")
root.Name = "Canvas"
root.AnchorPoint = Vector2.new(0.5, 0.5)
-- HUD RESCUE (2026-07-31) -- this canvas is CENTRED, with no inset
-- compensation, and that is deliberate. The compensation that used to live
-- here (`0.5, GuiInset().Y`) rested on a misread: AbsolutePosition inside an
-- IgnoreGuiInset=true ScreenGui is reported MINUS the topbar inset, so the
-- probe that saw Canvas.AbsolutePosition.Y = -57.3 was looking at a canvas
-- that was already perfectly centred. Adding the inset back pushed the whole
-- canvas 58px DOWN, which is what clipped the Settings rail item off the
-- bottom of the screen. Re-measured live before this fix: viewport 1891x772,
-- gui.AbsoluteSize 1891x772 (so the ScreenGui really is the full window),
-- GuiInset (0,58), Canvas.AbsolutePosition (273,0) -- reported 0 while its
-- true screen y was 58, exactly the -inset skew.
root.Size = UDim2.fromOffset(T.size.canvas.X, T.size.canvas.Y)
root.Position = UDim2.fromScale(0.5, 0.5)
root.BackgroundTransparency = 1
root.ZIndex = T.zindex.panel + 1 -- above Scrim (25), below Chrome (30)
root.Parent = gui

---------------------------------------------------------------- chrome layer
-- HUD RESCUE (2026-07-31): the user's complaint -- nav rail and currency
-- pills floating ~270px inboard instead of hugging the left edge of the
-- screen -- was the letterboxed canvas behaving exactly as designed. At the
-- measured 1891x772 viewport the 1350x775 canvas scales by 0.996 and renders
-- 1345 wide, so it CENTRES with its left edge at screen x=273. Anything
-- anchored to the canvas edge inherits that 273px offset.
--
-- So the HUD splits in two: modals stay on the centred canvas (a modal
-- SHOULD be centred), while HUD chrome -- currency cluster and nav rail --
-- moves onto this second layer, which is not letterboxed and spans the real
-- screen. Its UIScale runs at the identical factor, so everything on it
-- keeps the size it had; only the anchor changes.
--
-- Size is assigned in offset px as viewport/scale, so once this layer's own
-- UIScale multiplies it back up it covers exactly the safe area: full width,
-- top of screen + topbar inset down to the bottom. That keeps every child's
-- offsets in kit design px. The inset offset here is a real one (unlike the
-- canvas's above): these children hug the top-left corner, which is where
-- Roblox's own topbar buttons live.
local chrome = Instance.new("Frame")
chrome.Name = "Chrome"
chrome.AnchorPoint = Vector2.new(0, 0)
chrome.BackgroundTransparency = 1
chrome.ZIndex = T.zindex.rail -- 30: above the canvas, so the rail stays visible over open panels
chrome.Parent = gui

-- Uniform fit-to-viewport scale (kit README section 1). Exactly ONE
-- connection drives this for the whole HUD -- both layers and everything
-- under them -- so nothing else needs its own resize listener.
local canvasScale = Instance.new("UIScale")
canvasScale.Parent = root

local chromeScale = Instance.new("UIScale")
chromeScale.Parent = chrome

-- Assigned once the rail exists, further down: the rail centres itself
-- within the chrome layer's height, and that height is viewport-dependent,
-- so it has to be recomputed on every fit().
local layoutRail = nil

local function fit()
	local camera = workspace.CurrentCamera
	if not camera then return end
	local vp = camera.ViewportSize
	local scale = math.min(vp.X / T.size.canvas.X, vp.Y / T.size.canvas.Y)
	canvasScale.Scale = scale
	chromeScale.Scale = scale

	-- Re-read every pass rather than once at construction: GetGuiInset() can
	-- still return 0 at the instant this script first runs, before Roblox has
	-- populated the topbar inset.
	local inset = GuiService:GetGuiInset().Y
	chrome.Position = UDim2.fromOffset(0, inset)
	chrome.Size = UDim2.fromOffset(vp.X / scale, math.max(vp.Y - inset, 1) / scale)

	if layoutRail then layoutRail() end
end
fit()
do
	local camera = workspace.CurrentCamera
	if camera then
		camera:GetPropertyChangedSignal("ViewportSize"):Connect(fit)
	end
end
-- Covers the case where GetGuiInset() raced boot AND ViewportSize never
-- changes again this session (a fixed window), so nothing else re-runs fit().
task.delay(1, fit)

---------------------------------------------------------------- scrim
-- HUD RESCUE (2026-07-31): a sibling of the canvas, not a child of it. As a
-- child it only ever darkened the canvas, leaving the letterbox bars (273px
-- down each side at the measured 1891x772) bright behind an open modal.
local scrim = Instance.new("Frame")
scrim.Name = "Scrim"
scrim.Size = UDim2.fromScale(1, 1)
scrim.BackgroundColor3 = T.scrim
scrim.BackgroundTransparency = T.scrimAlpha
scrim.BorderSizePixel = 0
scrim.Visible = false
scrim.ZIndex = T.zindex.panel -- 25: below Canvas (26), so panels sit above it
scrim.Parent = gui

---------------------------------------------------------------- panel host
-- Panel Build(ctx) functions parent their own (e.g. 960-wide) panel Frame
-- into this host and centre themselves within it.
--
-- HUD RESCUE (2026-07-31): the host now fills the whole canvas, so those
-- panels land dead centre. It used to carry T.size.panelRightGutter (132) of
-- left padding to reserve the nav rail, which pushed every modal 54px right
-- of centre -- and the rail does not live on this canvas any more (see the
-- chrome layer). No collision either way: a 960-wide panel on the 1350 design
-- canvas leaves 195px gutters, clear of the rail's 116px column even when the
-- canvas spans the full screen width.
local host = Instance.new("Frame")
host.Name = "PanelHost"
host.Size = UDim2.fromScale(1, 1)
host.BackgroundTransparency = 1
host.Visible = false
host.ZIndex = T.zindex.panel + 1 -- 26: directly above the scrim, per brief Step 2
host.Parent = root

---------------------------------------------------------------- shared state
-- Forward-declared so the currency cluster / rail sections below can close
-- over them, and so `ctx` exists (as a table reference) before openPanel is
-- ever CALLED, even though its fields are filled in further down.
local ctx = {}

local state = {
	screen = "none", -- "none" | "pass" | "backpack" | "settings" | "daily" | "index" | "goals"
	pass = { level = 0, xp = 0, xpNeed = 0, passOwned = false, claimedFree = {}, claimedPass = {} },
	backpack = { tab = "Brainrots", selectedUid = nil, items = {} },
	settings = { music = 1, sfx = 1, quality = "Medium", toggles = {} },
	daily = { streakDay = 1, claimedToday = false },
	goals = { tab = "Daily", quests = {} },
	index = { filter = "All", entries = {} },
}

local panelModules = {}   -- id -> { Id, Build }
local panelInstances = {} -- id -> built Frame
local currentPanelId = nil
local railItems = {}      -- id -> { frame, glow, scale, claim }
local railBadges = {}     -- id -> badge Frame

-- FIX F3 (2026-07-30 fix wave): generation counter guarding closePanel's
-- delayed hide callback -- same claimMotionGen idiom DailyPanel's claim-
-- resolve motion uses. Bumped on EVERY openPanel and closePanel call; the
-- task.delay(panelClose.Time, ...) callback below captures its own gen and
-- no-ops unless it's still current when it fires.
local closeGen = 0

local openPanel, closePanel, setBadge, pillAnchor -- assigned below, exposed via ctx

local ID_TO_SCREEN = {
	bag = "backpack", pass = "pass", daily = "daily",
	goals = "goals", index = "index", settings = "settings",
}

---------------------------------------------------------------- number format
-- Same abbreviation family DarrelHUDClient uses (NumberFormat.Short),
-- replicated locally per the brief rather than requiring that module.
local UNITS = {
	{ 1e18, "Qi" }, { 1e15, "Qa" }, { 1e12, "T" },
	{ 1e9, "B" }, { 1e6, "M" }, { 1e3, "K" },
}
local function trunc2(x) return math.floor(x * 100) / 100 end
local function shortNumber(n)
	if type(n) ~= "number" or n ~= n then return "0" end
	if n == math.huge then return "\u{221E}" end
	if n == -math.huge then return "-\u{221E}" end
	local sign = n < 0 and "-" or ""
	n = math.abs(n)
	for _, unit in ipairs(UNITS) do
		if n >= unit[1] then
			return sign .. string.format("%.2f%s", trunc2(n / unit[1]), unit[2])
		end
	end
	return sign .. tostring(math.floor(n))
end

local function playPop(popScale)
	popScale.Scale = 0.85
	TweenService:Create(popScale, T.tween.pop, { Scale = 1 }):Play()
end

---------------------------------------------------------------- icon fallback
-- HUD RESCUE (2026-07-31): the kit's 8 icon PNGs are not imported yet, so
-- every Tokens.icons entry is still "" and UI.artSlot renders an unfilled
-- slot as a bare dark rounded box. Six of those stacked down the rail read
-- as "the UI is broken" -- which is how the live HUD looked. Until the ids
-- land, an unfilled slot gets the kit's chunky treatment (goldSmall
-- gradient + gloss on the rail's larger tiles) and a big centred emoji
-- standing in for the art. A slot whose id IS filled is left completely
-- alone, so pasting real ids into Tokens.icons silently retires all of this
-- with no further edit here.
-- Glyphs checked one by one against this build's emoji font on a throwaway
-- board in Play (same discipline the SFX work uses for audio: never pick by
-- name alone). U+1FA99 COIN, the obvious choice for the cash pill, renders
-- as an EMPTY BOX in Roblox -- it is Emoji 12.0 and the bundled font predates
-- it -- so cash uses U+1F4B0 MONEY BAG, which renders. Every other glyph here
-- was confirmed rendering at TextSize 90. If you add one, prove it the same
-- way before trusting it.
local GLYPH = {
	bag = "\u{1F392}", pass = "\u{1F3AB}", daily = "\u{1F4C5}",
	goals = "\u{1F4CB}", index = "\u{1F4D6}", settings = "\u{2699}",
	coin = "\u{1F4B0}", gem = "\u{1F48E}",
	-- darrel has no kit PNG and never will (he is ours, not the kit's), so this
	-- is only reached if IconArt itself fails to load; the diamond is the same
	-- stand-in the currency used before he had a face.
	darrel = "\u{1F48E}",
	-- rebirth is also ours (7th button, no kit PNG): only reached if IconArt
	-- fails to load. U+2B50 is the same star the legacy SideRail tile used,
	-- proven rendering there since 07-26.
	rebirth = "\u{2B50}",
}

local function glyphFallback(slot, key, textSize, plated)
	local id = T.icons[key]
	if id and id ~= "" then return nil end -- real art imported: leave the slot untouched
	if plated then
		slot.BackgroundTransparency = 0
		slot.BackgroundColor3 = T.color.white
		UI.gradient(slot, T.gradient.goldSmall)
		UI.gloss(slot, T.radius.small)
	end
	local glyph = Instance.new("TextLabel")
	glyph.Name = "Glyph"
	glyph.BackgroundTransparency = 1
	glyph.Size = UDim2.fromScale(1, 1)
	glyph.Text = GLYPH[key] or "?"
	glyph.TextSize = textSize
	glyph.TextColor3 = T.color.white
	glyph.TextXAlignment = Enum.TextXAlignment.Center
	glyph.TextYAlignment = Enum.TextYAlignment.Center
	-- Deliberately NOT T.font.display: FredokaOne carries no emoji glyphs, and
	-- the default face falls back to the system emoji font cleanly.
	glyph.ZIndex = slot.ZIndex + 2 -- above UI.gloss's Gloss/Shade (slot.ZIndex + 1)
	glyph.Parent = slot
	return glyph
end

---------------------------------------------------------------- currency cluster
-- Top 18 / left 18, gap 12 (kit README 3.7).
--
-- 2026-08-05: the cluster STAYS VISIBLE while a panel is open. It used to be
-- hidden on every openPanel, so opening Goals (or any other panel) blanked
-- your coin/gem counts -- which reads as the menu having eaten your currency,
-- and is the exact opposite of what you want on a screen whose whole job is
-- showing you what a reward costs or pays. It lives on the `chrome` layer
-- (ZIndex 30), a SIBLING of the canvas (26) and scrim (25), so it already
-- renders above an open panel with no z-fighting -- the same treatment the
-- nav rail on that layer has always had. No panel reaches it either: the
-- widest one is 960 design px on the 1350 canvas, leaving 195px gutters, and
-- the cluster ends ~150px in.
local currencyCluster = Instance.new("Frame")
currencyCluster.Name = "CurrencyCluster"
currencyCluster.Position = UDim2.fromOffset(18, 18)
currencyCluster.Size = UDim2.new(0, 0, 0, T.size.currencyPill)
currencyCluster.AutomaticSize = Enum.AutomaticSize.X
currencyCluster.BackgroundTransparency = 1
currencyCluster.ZIndex = T.zindex.currency
currencyCluster.Parent = chrome -- screen edge, not canvas edge (see the chrome layer)

local clusterList = Instance.new("UIListLayout")
clusterList.FillDirection = Enum.FillDirection.Horizontal
clusterList.VerticalAlignment = Enum.VerticalAlignment.Center
clusterList.SortOrder = Enum.SortOrder.LayoutOrder
clusterList.Padding = UDim.new(0, 12)
clusterList.Parent = currencyCluster

-- Pill height 54, radius 999, stroke 4, padding 0 18 0 6, 38px circular icon
-- slot (stroke 3) + value 24 (kit README 3.7).
--
-- Bug A fix (ui-overhaul checkpoint-1 fix wave): UI.gloss's Gloss/Shade
-- frames are Scale=1-of-parent decorative overlays, not flex items -- they
-- used to sit directly on `pill` alongside a horizontal UIListLayout that
-- swept them into the same row as IconSlot/Value (an undefined layout combo
-- once `pill` also carried AutomaticSize.X -- measured AbsoluteSize.X ~5700
-- in Play, see task-4-report.md). Builders' UI.gloss() itself is untouched
-- (panels depend on its current behaviour); instead the padding + list
-- layout + icon/value now live in a `Content` wrapper Frame that fills
-- `pill`, so Gloss/Shade stay untouched full-bleed siblings on `pill` and
-- never enter anyone's layout. `pill` itself is now explicitly sized --
-- icon + list gaps + measured text width + the kit's own padding --
-- recomputed via sizePillToValue() every time the value label's text
-- changes, with NO AutomaticSize anywhere on the pill.
local PILL_ICON_W = 38
local PILL_GAP = 8
local PILL_PAD_LEFT, PILL_PAD_RIGHT = 6, 18

local function sizePillToValue(pill, value)
	local spec = T.text.value
	local textWidth = TextService:GetTextSize(
		value.Text, spec[1], Enum.Font.FredokaOne, Vector2.new(1000, spec[1] + 24)
	).X
	local width = PILL_PAD_LEFT + PILL_ICON_W + PILL_GAP + textWidth + PILL_PAD_RIGHT
	pill.Size = UDim2.fromOffset(width, T.size.currencyPill)
end

-- `iconKey` names the pill (GemPill etc, which pillAnchor and the panels' coin
-- flight resolve against) while `artKey` chooses the artwork. They differ for
-- the second pill: it is the kit's "gem" slot structurally, but the currency it
-- counts is darrels, so it wears Darrel's face rather than a generic diamond.
local function buildPill(order, gradientKey, iconKey, artKey)
	artKey = artKey or iconKey
	local pill = Instance.new("Frame")
	pill.Name = iconKey:sub(1, 1):upper() .. iconKey:sub(2) .. "Pill"
	pill.LayoutOrder = order
	pill.Size = UDim2.new(0, 0, 0, T.size.currencyPill) -- real width set below by sizePillToValue
	pill.BackgroundColor3 = T.color.white
	pill.BorderSizePixel = 0
	pill.ZIndex = T.zindex.currency
	pill.Parent = currencyCluster
	UI.corner(pill, T.radius.pill)
	UI.gradient(pill, T.gradient[gradientKey])
	UI.stroke(pill, T.stroke.control)
	UI.gloss(pill, T.radius.pill) -- Gloss/Shade land directly on `pill`, outside Content's layout

	local content = Instance.new("Frame")
	content.Name = "Content"
	content.Size = UDim2.fromScale(1, 1)
	content.BackgroundTransparency = 1
	content.ZIndex = pill.ZIndex + 2 -- above Gloss/Shade (frame.ZIndex+1 in UI.gloss)
	content.Parent = pill

	local pad = Instance.new("UIPadding")
	pad.PaddingLeft = UDim.new(0, PILL_PAD_LEFT)
	pad.PaddingRight = UDim.new(0, PILL_PAD_RIGHT)
	pad.Parent = content

	local list = Instance.new("UIListLayout")
	list.FillDirection = Enum.FillDirection.Horizontal
	list.VerticalAlignment = Enum.VerticalAlignment.Center
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Padding = UDim.new(0, PILL_GAP)
	list.Parent = content

	-- The kit's own coin/gem artwork carries its keyline and its rim, so with
	-- IconArt supplying it the slot is a bare transparent host -- no dark disc,
	-- no extra stroke. Only an imported image id still needs the art-slot
	-- treatment (circular crop + stroke) to sit right in the pill.
	local icon: GuiObject
	local iconId = T.icons[artKey]
	if iconId and iconId ~= "" then
		icon = UI.artSlot(content, UDim2.fromOffset(PILL_ICON_W, PILL_ICON_W), iconId)
		local iconCorner = icon:FindFirstChildOfClass("UICorner")
		if iconCorner then iconCorner.CornerRadius = UDim.new(1, 0) end -- circular, not the art-slot default
		UI.stroke(icon, 3)
	else
		local host = Instance.new("Frame")
		host.Size = UDim2.fromOffset(PILL_ICON_W, PILL_ICON_W)
		host.BackgroundTransparency = 1
		host.Parent = content
		icon = host
		if IconArt and IconArt.has(artKey) then
			IconArt.draw(host, artKey, PILL_ICON_W, content.ZIndex + 1)
		else
			glyphFallback(host, artKey, 24, false) -- last resort, unplated
		end
	end
	icon.Name = "IconSlot"
	icon.LayoutOrder = 1
	icon.ZIndex = content.ZIndex + 1

	local value = UI.label(content, "0", "value", T.color.white)
	value.Name = "Value"
	value.LayoutOrder = 2
	value.ZIndex = content.ZIndex + 1
	value.TextYAlignment = Enum.TextYAlignment.Center

	local popScale = Instance.new("UIScale")
	popScale.Parent = pill

	sizePillToValue(pill, value)

	return pill, value, popScale
end

local coinPill, coinValueLabel, coinPop = buildPill(1, "goldSmall", "coin")
local gemPill, gemValueLabel, gemPop = buildPill(2, "gem", "gem", "darrel")

local cash, darrels = 0, 0
local hasCashLoaded, hasDarrelsLoaded = false, false

-- alive pass #2: gains COUNT UP over 0.35s (Quint/Out via a tweened
-- NumberValue); spends snap instantly -- counting down reads as slow loss.
-- Retarget rule: a new value mid-count starts from the number currently
-- DISPLAYED, never the stale target. The pill has no AutomaticSize (Bug A),
-- so width re-tracks on every tick of the count.
-- COUNT-UP DRIVER.
--
-- CLAUDE.md says never lerp in a RunService loop for something a tween can do.
-- Measured in this place, a tween CANNOT do this. TweenService animates
-- GuiObject properties -- Frame.Size tweens fine, which is what drives the quest
-- bar fill -- but does NOT animate non-GuiObject instances. UIScale.Scale,
-- NumberValue.Value and Sound.Volume were each probed live and each sat at
-- whatever value it was last set to while its tween "ran". So a NumberValue
-- tween drove nothing, and the pill only ever updated via the snap path.
--
-- Stepped write on a task loop instead, token-guarded so a new target supersedes
-- the previous driver rather than two fighting over the label. The tuned
-- Quint-out shape is applied by hand, so the feel matches what was specified.
local function makeTicker(pillFrame, valueLabel, duration)
	local shown = 0
	local token = 0
	local function paint(v)
		valueLabel.Text = shortNumber(math.floor(v))
		sizePillToValue(pillFrame, valueLabel)
	end
	return function(target, animate)
		token += 1
		local myToken = token
		if not animate then
			shown = target
			paint(target)
			return
		end
		-- retarget from where the number VISIBLY is, so a burst of payouts
		-- chases one moving target and can never step backwards
		local from = shown
		local span = target - from
		local secs = duration or 0.35
		task.spawn(function()
			local t0 = os.clock()
			while true do
				if myToken ~= token then return end
				local a = math.clamp((os.clock() - t0) / secs, 0, 1)
				shown = from + span * (1 - (1 - a) ^ 5)   -- Quint out
				paint(shown)
				if a >= 1 then break end
				task.wait()
			end
			if myToken == token then shown = target; paint(target) end
		end)
	end
end
-- =========================== CASH GAIN FEEDBACK ===========================
-- A payout used to change the total silently. Now: the pill pops in the
-- direction of the change, and an increase floats a "+N" off the pill.
--
-- INCOME vs EVENT. IncomeLoop fires CashTick every 0.35s and nothing else on
-- the server fires it (verified), so CashTick IS the income channel and
-- DataUpdated carries the deliberate payouts -- catches, sales, claims. That
-- split needs no server change and is the whole reason this can batch income
-- without batching the things the player actually did.
--   income -> accumulate, at most one float per second, NO sound
--   event  -> float immediately, WITH the cash sound
-- Back-out and Quad-out written as plain functions, because the engine's
-- EasingStyle is only reachable through TweenInfo and tweens do not drive
-- UIScale here. c1/c3 are the standard Back constants.
local function easeBackOut(a)
	local c1, c3 = 1.70158, 2.70158
	return 1 + c3 * (a - 1) ^ 3 + c1 * (a - 1) ^ 2
end
local function easeQuadOut(a) return 1 - (1 - a) ^ 2 end
local POP_UP   = { from = 1.14, time = 0.26, ease = easeBackOut }
local POP_DOWN = { from = 0.92, time = 0.18, ease = easeQuadOut }
local FLOAT_RISE   = 38     -- px travelled
local FLOAT_TIME   = 0.75   -- seconds to travel it
local FLOAT_FADE_AT = 0.45  -- seconds before fade begins
local FLOAT_POOL   = 4      -- hard cap; the oldest is recycled, never a 5th instance
local INCOME_BATCH = 1.0    -- seconds of income folded into a single float

-- Same measured limitation as the ticker: a TweenService tween on UIScale.Scale
-- does not run in this place (probed live -- the scale sat at its start value
-- for the whole tween). Stepped, token-guarded, easing applied by hand so the
-- specified Back-out / Quad-out shapes survive.
local popToken = {}
local function playPopDir(popScale, spec)
	popToken[popScale] = (popToken[popScale] or 0) + 1
	local myToken = popToken[popScale]
	local from = spec.from
	local secs = spec.time
	local ease = spec.ease
	popScale.Scale = from
	task.spawn(function()
		local t0 = os.clock()
		while true do
			if popToken[popScale] ~= myToken then return end
			local a = math.clamp((os.clock() - t0) / secs, 0, 1)
			popScale.Scale = from + (1 - from) * ease(a)
			if a >= 1 then break end
			task.wait()
		end
		if popToken[popScale] == myToken then popScale.Scale = 1 end
	end)
end

-- POOLED. Four labels are built once and reused forever; a burst of payouts
-- recycles the oldest rather than allocating, so the pool size IS the cap.
local floatPool, floatNext = {}, 1
for i = 1, FLOAT_POOL do
	local l = UI.label(coinPill, "", "chip", T.color.textAccent)
	l.Name = "CashGain" .. i
	l.AnchorPoint = Vector2.new(0, 0.5)
	l.AutomaticSize = Enum.AutomaticSize.XY
	l.Visible = false
	l.ZIndex = coinPill.ZIndex + 6
	floatPool[i] = { label = l, token = 0 }
end

local function floatGain(amount)
	if amount < 1 then return end
	local slot = floatPool[floatNext]
	floatNext = floatNext % FLOAT_POOL + 1
	slot.token += 1
	local myToken = slot.token
	local l = slot.label

	l.Text = "+" .. shortNumber(math.floor(amount))
	l.TextTransparency = 0
	for _, d in ipairs(l:GetChildren()) do
		if d:IsA("UIStroke") then d.Transparency = 0 end
	end
	-- starts low and right of the pill and rises past it: reads as the payout
	-- travelling INTO the counter. Kept off the pill's own footprint so it
	-- never covers the number it is describing.
	l.Position = UDim2.new(1, 10, 0.5, 20)
	l.Visible = true

	TweenService:Create(l, TweenInfo.new(FLOAT_TIME, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
		{ Position = UDim2.new(1, 10, 0.5, 20 - FLOAT_RISE) }):Play()
	task.delay(FLOAT_FADE_AT, function()
		if slot.token ~= myToken then return end   -- recycled early: leave it to its new owner
		local fade = TweenInfo.new(FLOAT_TIME - FLOAT_FADE_AT, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		TweenService:Create(l, fade, { TextTransparency = 1 }):Play()
		for _, d in ipairs(l:GetChildren()) do
			if d:IsA("UIStroke") then TweenService:Create(d, fade, { Transparency = 1 }):Play() end
		end
	end)
	task.delay(FLOAT_TIME + 0.05, function()
		if slot.token == myToken then l.Visible = false end
	end)
end

-- income accumulator: one float per INCOME_BATCH at most, no sound
local incomePending, incomeFlushQueued = 0, false
local function queueIncomeFloat(delta)
	incomePending += delta
	if incomeFlushQueued then return end
	incomeFlushQueued = true
	task.delay(INCOME_BATCH, function()
		incomeFlushQueued = false
		local n = incomePending
		incomePending = 0
		if n >= 1 then floatGain(n) end
	end)
end

local tickCash = makeTicker(coinPill, coinValueLabel, 0.45)   -- U2 tuning
local tickDarrels = makeTicker(gemPill, gemValueLabel)         -- gem pill untouched this round

-- source: "income" (CashTick, IncomeLoop's 0.35s tick) or "event" (a payout the
-- player caused). Defaults to "event" so any future caller is loud, not silent.
local function applyCash(n, source)
	if typeof(n) ~= "number" then return end
	local prev = cash
	cash = n
	local gained = hasCashLoaded and n > prev
	tickCash(n, gained)
	if hasCashLoaded then
		if n > prev then
			playPopDir(coinPop, POP_UP)
			local delta = n - prev
			if source == "income" then
				queueIncomeFloat(delta)          -- batched, silent
			else
				floatGain(delta)                 -- immediate
				SoundKit.play("cash", nil, { volume = 0.22 })
			end
		elseif n < prev then
			playPopDir(coinPop, POP_DOWN)        -- spending reads as a dip, not a bounce
		end
	end
	hasCashLoaded = true
end

local function applyDarrels(n)
	if typeof(n) ~= "number" then return end
	local prev = darrels
	darrels = n
	tickDarrels(n, hasDarrelsLoaded and n > prev)
	if hasDarrelsLoaded and n > prev then playPop(gemPop) end
	hasDarrelsLoaded = true
end

remotes.DataUpdated.OnClientEvent:Connect(function(payload)
	if typeof(payload) ~= "table" then return end
	if payload.Cash ~= nil then applyCash(payload.Cash, "event") end
end)

-- THE REAL DEFECT THIS ROUND FIXES. IncomeLoop fires CashTick every 0.35s, and
-- the visible pill was never subscribed to it -- only ClientMain (whose label
-- GameHUDClient retires) and TradeClient/MerchantClient were. So a stocked plot
-- earned continuously while the pill the player actually looks at sat still
-- until some unrelated event happened to fire DataUpdated.
remotes.CashTick.OnClientEvent:Connect(function(n)
	applyCash(n, "income")
end)

-- Bug C2 fix (gem seed redesign, round-2): applies unconditionally whenever
-- the payload carries a real number -- no latch/flag coordinating this with
-- the startup retry loop below. Whichever lands last (this push, or a
-- successful retry-loop pull) simply overwrites gemPill; last write wins.
remotes.DarrelUpdate.OnClientEvent:Connect(function(payload)
	if typeof(payload) ~= "table" then return end
	if typeof(payload.Darrels) == "number" then
		applyDarrels(payload.Darrels)
	end
end)

-- Startup pulls, mirroring DarrelHUDClient/EggShopClient's own join-time
-- invoke pattern: the push above can race this script's listener connecting.
task.spawn(function()
	local ok, snap = pcall(function() return remotes.GetInitialData:InvokeServer() end)
	if ok and typeof(snap) == "table" then applyCash(snap.Cash) end
end)

-- Bug C3 fix (gem seed, round-4 -- ACTUAL ROOT CAUSE). The previous two
-- redesigns both tuned the RETRY logic (latch -> latch-free, 3x2s -> 5x2s),
-- but the loop was never retrying at all: it "succeeded" on attempt 1, a
-- fraction of a second after join, and returned for good.
--
-- DarrelService.M.Get is `local data = PDM.Get(player); return data and
-- data.Darrels or 0`, and PlayerDataManager.Get is a plain
-- `cache[player.UserId]` lookup that stays nil until the async DataStore
-- load lands. So any pull that beats the profile load returns a PLACEHOLDER
-- {Darrels = 0}, and `typeof(res.Darrels) == "number"` is perfectly true of
-- 0 -- a "valid" result indistinguishable from this pill's own seed text,
-- which is exactly why it always looked like the pull never landed. Nothing
-- corrected it afterwards either: DarrelService.Init's join-time push is
-- itself guarded by `if data then`, so it no-ops on the same unloaded
-- profile and DarrelUpdate never fires at join at all.
--
-- The response already carries an unambiguous loaded/not-loaded
-- discriminator: M.GetDailyState returns nil for an unloaded profile (`if
-- not data then return nil end`) and a real table once loaded -- driven by
-- the very same `data` nil-check that produces the placeholder 0. So keep
-- pulling until `Daily` proves the profile is loaded, applying whatever came
-- back on every pass (so a player whose real balance IS 0 still displays
-- immediately), and stop the instant the value is known to be real.
task.spawn(function()
	for attempt = 1, 20 do
		local ok, res = pcall(function() return remotes.DarrelState:InvokeServer() end)
		if ok and typeof(res) == "table" and typeof(res.Darrels) == "number" then
			applyDarrels(res.Darrels)
			if typeof(res.Daily) == "table" then
				return -- profile is loaded; this value is real
			end
		end
		task.wait(1)
	end
end)

---------------------------------------------------------------- nav rail
-- v2 spec (kit README 3.7, pixel-adjudicated against captures/hud.png):
-- inset 10, vertically centred, gap 6 -- NO button plate, the icon
-- floats bare. Item column width 106: 66x66 icon, label directly under it
-- (T.text.railLabel: Fredoka One 20 / stroke 4). Active state = an 88px
-- radial gold glow behind the icon (T.size.railGlow / T.color.activeGlow),
-- not a ring around a plate that no longer exists. Notification badge:
-- top -6 / right 12 relative to the item column. Hover translateY(-3) +
-- scale(1.03), press translateY(+2) + scale(0.99) (kit README section 4).
--
-- ui(3-fix1) user decision (2026-07-30): the rail moves to the LEFT edge
-- of the canvas -- the kit drew it on the right. Reading the Tokens side
-- setting keeps the edge choice data-driven, so a future flip only touches
-- Tokens.lua; T.size.railInset still supplies the inset distance either way.
local RAIL_ON_LEFT = (T.size.railSide == "left")

-- Vertically centred BELOW the currency cluster's band, not across the whole
-- layer: the pills occupy y 18-72 and the rail shares their left edge, so it
-- centres within [96, layer height - 72] instead.
--
-- HUD RESCUE (2026-07-31): that band is measured against the LIVE viewport
-- (via the chrome layer) rather than the 775px design canvas, and the rail
-- scales down when the band is shorter than the column it has to hold. The
-- old constant assumed the full design height was always available; on the
-- measured 1891x772 window the real band is ~549px against a 618px column,
-- so the rail overflowed the bottom of the screen and took the Settings item
-- with it. The bottom reserve is what keeps it clear of WheelClient's
-- bottom-left FastSpinToggle (measured live at x[22..190] y[702..748]
-- true-screen, deliberately parked under the rail there -- see WheelClient's
-- "Bug E fix" comment). Those two columns overlap horizontally by ~82px, so
-- the vertical gap is the only thing separating them: a 72px reserve measured
-- out at 2.5px of clearance, which is not a margin, it is a coincidence. 88
-- puts the rail's bottom at ~683 for ~19px of real gap, and costs only ~2px
-- off each icon (56.6px rendered, still well clear of the kit's 44px minimum
-- touch target).
local RAIL_TOP_CLEARANCE = 96
local RAIL_BOTTOM_RESERVE = 88
local RAIL_ICON_GAP = 6
local RAIL_LABEL_H = 26
-- claim halo: a shade wider than the icon so it reads as a rim of gold
-- around the art, not a plate behind it
local RAIL_CLAIM_D = T.size.railIcon + 10

-- 2026-08-04 icon redesign (user handoff "Roblox game UI redesign", option
-- 3a): the rail wears the mock's frameless sticker treatment -- the EMOJI
-- GLYPH IS THE ICON, at the mock's per-icon size ladder (scaled 653->775 to
-- our canvas) and tilt, idle-bobbing with a 0.25s stagger; the Daily gift
-- wobbles instead (rotate about its base tilt -- Rotation tweens verified
-- running in this place, unlike the transparency/UIScale family). The kit
-- PNGs in T.icons and IconArt stay untouched underneath: delete a STICKER
-- entry and that slot falls straight back to the old art chain. Rebirth
-- deliberately has NO entry (user call: keep our drawn arc-over-star).
-- Every glyph below was render-proven live on a probe board this session.
-- NOTE: the mock's dark keyline is NOT achievable on colour emoji --
-- UIStroke (3px and 6px), legacy TextStroke and UIPolish are all no-ops on
-- them (probed live) -- so the glyphs ride bare with the shadow the emoji
-- art itself carries.
local STICKER = {
	bag      = { glyph = "\u{1F392}", size = 64, tilt = -5 },
	goals    = { glyph = "\u{2705}", size = 59, tilt = 4 },
	pass     = { glyph = "\u{2B50}", size = 64, tilt = 5 },
	index    = { glyph = "\u{1F4D8}", size = 62, tilt = -4 },
	daily    = { glyph = "\u{1F381}", size = 68, tilt = -6, wobble = true },
	settings = { glyph = "\u{2699}\u{FE0F}", size = 52, tilt = 4 },
}
local BOB_RISE = 7        -- px of idle lift (mock: 6 at reference scale)
local BOB_TIME = 1.6      -- half-cycle; full bob = 3.2s like the mock
local BOB_STAGGER = 0.25
local WOB_SWING = 3       -- degrees either side of the base tilt
local WOB_TIME = 1.3      -- half-cycle; full wobble = 2.6s

local RAIL_ORDER = {
	{ id = "bag", label = "Bag" },
	{ id = "pass", label = "Pass" },
	{ id = "daily", label = "Daily" },
	{ id = "goals", label = "Goals" },
	{ id = "index", label = "Index" },
	{ id = "settings", label = "Settings" },
	-- 7th button (2026-08-04): Rebirth's claim cue finally has a visible
	-- home; its click path is special -- see rebirthPanel() just below.
	-- Review catch: a THIRD column would overlap open panels' left edge at
	-- true 16:9 sizes (rail is true-screen chrome, panels are scaled canvas;
	-- at 1080p the panel edge sits ~screen-x 291 while a third column spans
	-- ~234..340) -- and its invisible hit button would steal panel clicks and
	-- force-close the panel via single-open. So the grid grows DOWN instead:
	-- two columns of four, RAIL_W stays 218, zero new overlap.
	{ id = "rebirth", label = "Rebirth" },
}

-- Rebirth's surface is still RebirthClient's own legacy panel
-- (PlayerGui.RebirthUI.RebirthPanel, built eagerly at join) -- there is no
-- GameHUDPanels module for it. Toggling that frame's Visible is the
-- sanctioned lever: the panel sits in SideRail.registerPanel's single-open
-- registry, so opening it force-closes `host` (and vice versa), and the
-- host watcher near the bottom of this file already resyncs our bookkeeping
-- when that happens.
local function rebirthPanel()
	local ui = playerGui:FindFirstChild("RebirthUI")
	return ui and ui:FindFirstChild("RebirthPanel") or nil
end

-- USER LAYOUT (2026-07-30): two columns of three instead of one column of six,
-- filled COLUMN-FIRST -- Bag/Pass/Daily down the left, Goals/Index/Settings
-- beside them. Anchored to the TOP of the band rather than centred in it, so
-- the left column keeps the on-screen position it already had. Three rows of
-- full-size items is 306px against a ~532px band, so railScale sits back at
-- 1.0 and the icons render at the kit's intended 66px again.
-- ============================================================================
-- 2026-08-04 SIDEBAR BLUEPRINT (user's "Roblox Simulator UI Blueprint (1:1)"
-- .docx). Replaces the 2x4 grid of frameless labelled icons with the
-- blueprint's sidebar: ONE column, vertically centred on the left edge,
-- 72px plated buttons 8px apart, NO permanent labels.
--   "Sidebar Position (0.02,0.5), AnchorPoint (0,0.5), width ~80px"
--   "Button 64x64 or 72x72 ImageButton, UICorner, UIStroke 3px, UIGradient,
--    Shadow"
--   "Hover scale 1.00->1.08 (0.08s). Click 1.08->0.92->1.00"
--   "Spacing 8px between icons, all same size"
--   "Style ... no permanent labels"
-- The labels are GONE per that last line -- the icon art plus the active
-- glow, badges and claim halos carry the meaning now.
-- ============================================================================
-- USER REFERENCE (2026-08-04): the sidebar art they want is a chunky icon on
-- a CREAM plate inside a heavy near-black outline. In that reference the
-- plate is part of the PNG (which is why the blueprint says "replace only
-- the icon image") -- but the icons currently in T.icons are an older, plain,
-- plate-less set, so until the real 512px art is uploaded the plate is drawn
-- here instead, in the reference's own colours. When the new art lands:
-- swap the T.icons ids and set RAIL_PLATE_DRAWN = false, and the artwork's
-- baked plate takes over with nothing behind it.
local RAIL_PLATE_DRAWN = true
local RAIL_PLATE_TOP = Color3.fromHex("#F7E7C2")   -- cream, reference plate top
local RAIL_PLATE_BOT = Color3.fromHex("#DFC28C")   -- warmer tan at the foot
local RAIL_PLATE_INK = Color3.fromHex("#171310")   -- the reference's heavy outline
local RAIL_PLATE_STROKE = 4                        -- thicker than the blueprint's 3: the reference outline is heavy
local RAIL_BTN = 72          -- blueprint "64x64 or 72x72"; 72 keeps the imported 512px art legible
local RAIL_BTN_GAP = 8       -- blueprint "8px between icons"
local RAIL_HOVER = 1.08      -- blueprint hover scale
local RAIL_PRESS = 0.92      -- blueprint click squash
local RAIL_HOVER_TIME = 0.08 -- blueprint "(0.08s)"
local RAIL_W = RAIL_BTN
local RAIL_H = #RAIL_ORDER * RAIL_BTN + (#RAIL_ORDER - 1) * RAIL_BTN_GAP

local rail = Instance.new("Frame")
rail.Name = "NavRail"
-- blueprint: AnchorPoint (0,0.5) -- the column is centred on the screen's
-- vertical midline instead of hanging from a top clearance
rail.AnchorPoint = if RAIL_ON_LEFT then Vector2.new(0, 0.5) else Vector2.new(1, 0.5)
rail.Size = UDim2.fromOffset(RAIL_W, RAIL_H)
rail.BackgroundTransparency = 1
rail.ZIndex = T.zindex.rail
rail.Parent = chrome -- screen edge, not canvas edge (see the chrome layer)

-- Shrink-to-fit, so the rail can never run off the bottom of the screen the
-- way it did before this rescue. 1.0 on any window tall enough for the kit's
-- full-size grid; below that it scales down, from the top-left, instead of
-- overflowing.
local railScale = Instance.new("UIScale")
railScale.Parent = rail

-- Fills the local forward-declared next to fit(), which calls this on every
-- viewport change -- the band depends on the live viewport height.
layoutRail = function()
	-- The blueprint's 0.5 centring is taken literally, but the shrink-to-fit
	-- guard stays: a single column of 7 buttons is 552px, and the band left
	-- between the top TabBar and WheelClient's bottom-left toggle is smaller
	-- than that on short windows. Scale down rather than overflow -- the same
	-- rescue the grid layout needed.
	local band = math.max(chrome.Size.Y.Offset - RAIL_TOP_CLEARANCE - RAIL_BOTTOM_RESERVE, 1)
	railScale.Scale = math.min(1, band / RAIL_H)
	-- blueprint "Position (0.02, 0.5)" -- a scale inset, not the old fixed 10px
	if RAIL_ON_LEFT then
		rail.Position = UDim2.new(0.02, 0, 0.5, 0)
	else
		rail.Position = UDim2.new(0.98, 0, 0.5, 0)
	end
end
layoutRail()

-- Placed by hand rather than by a UIListLayout: the grid is column-first,
-- which no single FillDirection expresses, and a layout-managed child ignores
-- writes to its Position -- which had quietly been making the hover/press
-- translate below a no-op (only the scale half of it was landing).
for order, cfg in ipairs(RAIL_ORDER) do
	-- `item` is a transparent WRAPPER, centred in its slot, and every child
	-- below sizes in SCALE units -- so the blueprint's hover/press scaling can
	-- be driven by tweening this one frame's Size and the plate, shadow, icon
	-- and glow all follow it. (It cannot ride a UIScale: UIScale tweens do not
	-- run in this place -- which is why the old rail's "scale 1.03" hover was
	-- a silent no-op the whole time it shipped.)
	local item = Instance.new("Frame")
	item.Name = cfg.id .. "Item"
	item.LayoutOrder = order
	item.AnchorPoint = Vector2.new(0.5, 0.5)
	item.Position = UDim2.new(0.5, 0, 0, (order - 1) * (RAIL_BTN + RAIL_BTN_GAP) + RAIL_BTN / 2)
	item.Size = UDim2.fromOffset(RAIL_BTN, RAIL_BTN)
	item.BackgroundTransparency = 1
	item.ZIndex = T.zindex.rail
	item.Parent = rail

	-- blueprint "Shadow": the guide's hard offset shadow, as a scale-sized
	-- sibling INSIDE the wrapper so it scales with the hover instead of
	-- detaching from the plate (UI.hardShadow parents as an outside sibling
	-- and copies a fixed Size -- wrong for a frame whose Size is tweened)
	local plateShadow = Instance.new("Frame")
	plateShadow.Name = "PlateShadow"
	plateShadow.Size = UDim2.fromScale(1, 1)
	plateShadow.Position = UDim2.fromOffset(0, 4)
	plateShadow.BackgroundColor3 = RAIL_PLATE_INK
	plateShadow.BackgroundTransparency = 0.3
	plateShadow.BorderSizePixel = 0
	plateShadow.Visible = RAIL_PLATE_DRAWN
	plateShadow.ZIndex = item.ZIndex
	plateShadow.Parent = item
	UI.corner(plateShadow, T.radius.control)

	-- blueprint "UICorner, UIStroke 3px, UIGradient" -- the plate the icon
	-- sits on. This is the piece the 3a direction removed ("the icon IS the
	-- button") and the blueprint brings back.
	local plate = Instance.new("Frame")
	plate.Name = "Plate"
	plate.Size = UDim2.fromScale(1, 1)
	plate.BackgroundColor3 = RAIL_PLATE_TOP
	plate.BorderSizePixel = 0
	plate.Visible = RAIL_PLATE_DRAWN
	plate.ZIndex = item.ZIndex + 1
	plate.Parent = item
	UI.corner(plate, T.radius.control)
	-- cream -> tan, the reference's own plate, NOT the guide's gray window
	-- family: this stands in for artwork that will arrive with its plate
	-- already painted on, so it follows the art, not the panel chrome.
	UI.gradient(plate, ColorSequence.new(RAIL_PLATE_TOP, RAIL_PLATE_BOT))
	local plateInk = UI.stroke(plate, RAIL_PLATE_STROKE)
	plateInk.Color = RAIL_PLATE_INK
	UI.gloss(plate, T.radius.control)

	-- v2: no button plate -- the icon floats directly on the item column,
	-- top-aligned, with the label directly under it. USER (2026-07-30): and no
	-- gold tile behind the art either. The slot is now a bare transparent host;
	-- what goes in it is the kit's own icon artwork, matching captures/hud.png.
	-- The art sits INSIDE the plate now, sized in scale so it rides the hover
	-- with everything else. 0.74 leaves the plate's stroke and gloss visible
	-- as a border around the icon rather than the art running to the edge.
	local icon = Instance.new("Frame")
	icon.Name = "IconSlot"
	icon.AnchorPoint = Vector2.new(0.5, 0.5)
	icon.Position = UDim2.fromScale(0.5, 0.5)
	icon.Size = UDim2.fromScale(0.74, 0.74)
	icon.BackgroundTransparency = 1
	icon.ZIndex = item.ZIndex + 3
	icon.Parent = item

	-- STYLE REPLACEMENT (2026-08-04, Pet-Sim guide): the emoji stickers are
	-- RETIRED. The guide's rule is a thick ink outline on every icon, and a
	-- colour emoji cannot carry one -- UIStroke (probed at 3px and 6px), the
	-- legacy TextStroke and the UIPolish sweep are all no-ops on them, so an
	-- emoji rail can never be in this style, only near it.
	-- Setting STICKER_ENABLED = false hands every slot back to the art chain
	-- below, which was never deleted: imported PNG art (T.icons, 8 ids live)
	-- wins, then UIKit.IconArt's primitive drawings (16 icons, real ink
	-- outlines -- exactly the "chunky vector icons" the guide asks for), then
	-- the emoji glyphFallback as a last resort. Flip this back to true to
	-- restore the 3a sticker look in one edit.
	local STICKER_ENABLED = false
	local sticker = STICKER_ENABLED and STICKER[cfg.id] or nil
	if sticker then
		-- redesign glyph wins over the old art chain (see STICKER above)
		local glyph = Instance.new("TextLabel")
		glyph.Name = "StickerGlyph"
		glyph.Size = UDim2.fromScale(1, 1)
		glyph.BackgroundTransparency = 1
		glyph.Font = Enum.Font.FredokaOne
		glyph.TextSize = sticker.size
		glyph.Text = sticker.glyph
		glyph.TextColor3 = T.color.white -- colour emoji ignore this; fallback only
		glyph.Rotation = sticker.tilt
		glyph.ZIndex = icon.ZIndex + 1
		-- emoji must not be re-coloured or outlined by the game-wide UIPolish
		-- sweep (SideRail convention; strokes are no-ops on emoji anyway)
		glyph:SetAttribute("NoPolish", true)
		glyph.Parent = icon
		if sticker.wobble then
			-- rock about the base tilt, engine-driven, no per-frame Lua
			glyph.Rotation = sticker.tilt - WOB_SWING
			TweenService:Create(glyph,
				TweenInfo.new(WOB_TIME, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
				{ Rotation = sticker.tilt + WOB_SWING }):Play()
		else
			-- idle bob on the icon SLOT (never `item`: hover/press tween item
			-- Position and capture a lazy rest pose -- bobbing there would
			-- corrupt basePos). Staggered like the mock so the rail ripples.
			local slotRest = icon.Position
			task.delay(order * BOB_STAGGER, function()
				if not icon.Parent then return end
				TweenService:Create(icon,
					TweenInfo.new(BOB_TIME, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
					{ Position = slotRest - UDim2.fromOffset(0, BOB_RISE) }):Play()
			end)
		end
	else
		local iconId = T.icons[cfg.id]
		if iconId and iconId ~= "" then
			-- imported art always wins once the ids land in Tokens
			local img = Instance.new("ImageLabel")
			img.Name = "Art"
			img.Size = UDim2.fromScale(1, 1)
			img.BackgroundTransparency = 1
			img.Image = iconId
			img.ScaleType = Enum.ScaleType.Fit
			img.ZIndex = icon.ZIndex + 1
			img.Parent = icon
		elseif IconArt and IconArt.has(cfg.id) then
			IconArt.draw(icon, cfg.id, T.size.railIcon, icon.ZIndex + 1)
		else
			glyphFallback(icon, cfg.id, 40, false) -- last resort, unplated
		end
		-- rebirth keeps its drawn icon (user call) but joins the mock's motion
		-- language with the staggered bob, so one dead-still icon doesn't read
		-- as broken in a rail of live ones. NO TILT, deliberately: rotating any
		-- ancestor of IconArt's clip frames disables ClipsDescendants (probed
		-- live at 4x -- the arch's keyline+purple rings render as FULL ovals
		-- looping through the star). Review catch.
		-- The idle bob is RETIRED with the sticker era: the blueprint's motion
		-- list is hover and click only, and one lone bobbing icon in a rail of
		-- still ones reads as a glitch rather than life.
	end

	-- NO LABEL: blueprint "no permanent labels". The art carries the meaning;
	-- the active glow, the count badge and the claim halo carry the state.

	-- Active state (kit README 3.7): "88px radial gold glow behind the
	-- icon, rgba(255,232,122,.75) centre -> transparent at 72%". Roblox's
	-- UIGradient has no radial mode, so this approximates the falloff with
	-- concentric circles (opaque centre, fading outward, capped ~72% of
	-- the radius) instead of a texture asset -- same non-native-primitive
	-- workaround convention as UI.rainbowRing above.
	local glow = Instance.new("Frame")
	glow.Name = "ActiveGlow"
	glow.AnchorPoint = Vector2.new(0.5, 0.5)
	-- centred on the PLATE now (scale units), not hung off the old icon-slot
	-- top edge, and sized in scale so it rides the hover with everything else
	glow.Position = UDim2.fromScale(0.5, 0.5)
	glow.Size = UDim2.fromScale(1.2, 1.2)
	glow.BackgroundTransparency = 1
	glow.Visible = false
	glow.ZIndex = item.ZIndex -- behind the plate
	glow.Parent = item

	local GLOW_RINGS = { -- {diameter fraction of railGlow, transparency} outer -> inner
		{ 0.70, 0.90 },
		{ 0.50, 0.72 },
		{ 0.30, 0.50 },
		{ 0.14, 0.25 }, -- innermost/most opaque, ~= rgba(255,232,122,.75)
	}
	for i, ringSpec in ipairs(GLOW_RINGS) do
		local d = ringSpec[1]
		local glowRing = Instance.new("Frame")
		glowRing.Name = "Ring" .. i
		glowRing.AnchorPoint = Vector2.new(0.5, 0.5)
		glowRing.Position = UDim2.fromScale(0.5, 0.5)
		glowRing.Size = UDim2.fromScale(d, d)
		glowRing.BackgroundColor3 = T.color.activeGlow
		glowRing.BackgroundTransparency = ringSpec[2]
		glowRing.BorderSizePixel = 0
		glowRing.ZIndex = glow.ZIndex
		glowRing.Parent = glow
		UI.corner(glowRing, 999) -- scale-sized now, so a pill radius keeps it round at any size
	end

	-- Claim halo (U3 port): SideRail's claim arbitration paints onto this --
	-- see attachClaimSurface below the loop. A single soft gold disc behind
	-- the icon. Visible/BackgroundTransparency are owned by SideRail: shown
	-- at rest alpha while claimable, breathed by its shared Heartbeat driver
	-- while this button holds pulse priority. Per-frame property writes, no
	-- TweenService (BackgroundTransparency tweens do not run in this place).
	local claimHalo = Instance.new("Frame")
	claimHalo.Name = "ClaimHalo"
	claimHalo.AnchorPoint = Vector2.new(0.5, 0.5)
	-- scale units, centred on the plate, same reason as ActiveGlow above
	claimHalo.Position = UDim2.fromScale(0.5, 0.5)
	claimHalo.Size = UDim2.fromScale(1.14, 1.14)
	claimHalo.BackgroundColor3 = T.color.activeGlow
	claimHalo.BackgroundTransparency = 0.35
	claimHalo.BorderSizePixel = 0
	claimHalo.Visible = false
	claimHalo.ZIndex = item.ZIndex -- behind the plate, beside ActiveGlow
	claimHalo.Parent = item
	UI.corner(claimHalo, 999)

	-- Hit target: invisible button over the whole plate. 72px is well clear of
	-- the 44px minimum touch target on its own now that the label is gone.
	local hit = Instance.new("TextButton")
	hit.Name = "Hit"
	hit.Text = ""
	hit.Size = UDim2.fromScale(1, 1)
	hit.BackgroundTransparency = 1
	hit.AutoButtonColor = false
	hit.ZIndex = item.ZIndex + 10
	hit.Parent = item
	wireClick(hit, "uiClick")

	-- blueprint motion: "Hover scale 1.00->1.08 (0.08s). Click 1.08->0.92->
	-- 1.00". Driven on the wrapper's SIZE, never a UIScale -- UIScale tweens
	-- do not run in this place, which is exactly why the rail's previous
	-- "scale 1.03" hover never actually scaled anything. AnchorPoint is
	-- (0.5,0.5), so Size alone grows the button about its own centre with no
	-- position compensation.
	local REST_SIZE = UDim2.fromOffset(RAIL_BTN, RAIL_BTN)
	local function sizeAt(mult)
		return UDim2.fromOffset(math.round(RAIL_BTN * mult), math.round(RAIL_BTN * mult))
	end
	local HOVER_INFO = TweenInfo.new(RAIL_HOVER_TIME, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local hovering = false

	hit.MouseEnter:Connect(function()
		hovering = true
		TweenService:Create(item, HOVER_INFO, { Size = sizeAt(RAIL_HOVER) }):Play()
	end)
	hit.MouseLeave:Connect(function()
		hovering = false
		TweenService:Create(item, HOVER_INFO, { Size = REST_SIZE }):Play()
	end)
	hit.MouseButton1Down:Connect(function()
		TweenService:Create(item, HOVER_INFO, { Size = sizeAt(RAIL_PRESS) }):Play()
	end)
	hit.MouseButton1Up:Connect(function()
		-- release settles to whichever state the cursor is actually in, so a
		-- click that drags off the button does not leave it stuck enlarged
		TweenService:Create(item, HOVER_INFO,
			{ Size = hovering and sizeAt(RAIL_HOVER) or REST_SIZE }):Play()
	end)
	hit.MouseButton1Click:Connect(function()
		if cfg.id == "rebirth" then
			-- legacy panel, not an openPanel id -- see rebirthPanel() above
			local panel = rebirthPanel()
			if panel then panel.Visible = not panel.Visible end
			return
		end
		if currentPanelId == cfg.id then
			closePanel()
		else
			openPanel(cfg.id)
		end
	end)

	railItems[cfg.id] = { frame = item, glow = glow, claim = claimHalo }
end

-- U3 port: these rail buttons are the claim surface now -- the legacy
-- LeftRail this used to happen on is hidden permanently further down this
-- file. SideRail's central arbitration (priority table + PULSE_MAX cap)
-- still decides WHO pulses; it just paints onto these halos. Rebirth joined
-- the map when it got its own rail button (2026-08-04). Type-guarded so an
-- older SideRail (two sessions edit this place) can never hard-error the
-- HUD build.
local CLAIM_SOURCE = { daily = "Daily", goals = "Goals", pass = "Season", rebirth = "Rebirth" }
if type(SideRail.attachClaimSurface) == "function" then
	for id, tileName in pairs(CLAIM_SOURCE) do
		local entry = railItems[id]
		if entry and entry.claim then
			SideRail.attachClaimSurface(tileName, entry.claim)
		end
	end
end

-- One renderer for every badge kind on the rail. "count" is the v2 kit badge
-- (red, numeric); "dot" is the same badge shrunk to a plain disc; "alert" is
-- the gold "!" the legacy tiles used for Rebirth. ctx.setBadge keeps its
-- numeric contract through the setBadge wrapper further down; SideRail's
-- reporters arrive here with their kind intact via attachBadgeSurface --
-- which also closes a real gap: the pass badge used to be absent until the
-- pass panel's FIRST open (PassPanel.Build is lazy), while SeasonClient
-- pushes the same claimable count from join+1s.
local BADGE_GOLD = ColorSequence.new(Color3.fromHex("#FFE87A"), Color3.fromHex("#E8930F"))
local function paintBadge(id, kind, n)
	local item = railItems[id]
	if not item then return end
	if kind == "none" or (kind == "count" and (not n or n <= 0)) then
		if railBadges[id] then
			railBadges[id]:Destroy()
			railBadges[id] = nil
		end
		return
	end
	local text = kind == "count" and ((n > 99) and "99+" or tostring(n))
		or kind == "alert" and "!"
		or ""
	local b = railBadges[id]
	-- a kind flip rebuilds; only same-kind updates retarget the label
	if b and b:GetAttribute("BadgeKind") ~= kind then
		b:Destroy()
		b = nil
		railBadges[id] = nil
	end
	if b then
		local label = b:FindFirstChild("Value")
		if label then label.Text = text end
		return
	end
	-- v2 (kit README 3.7): min-width 34, height 34, stroke 4, hard
	-- shadow 0 3, value 19, at top -6 / right 12 relative to the item
	-- column -- UI.badge ships the v1 defaults (30/30, stroke 3.5, no
	-- shadow, text 16), overridden here rather than in the shared builder.
	local d = (kind == "dot") and 18 or 34
	b = UI.badge(item.frame, text)
	b:SetAttribute("BadgeKind", kind)
	b.Size = UDim2.fromOffset(0, d)
	local sizeConstraint = b:FindFirstChildOfClass("UISizeConstraint")
	if sizeConstraint then sizeConstraint.MinSize = Vector2.new(d, d) end
	local badgeStroke = b:FindFirstChildOfClass("UIStroke")
	if badgeStroke then badgeStroke.Thickness = (kind == "dot") and 3 or 4 end
	local valueLabel = b:FindFirstChild("Value")
	if valueLabel then valueLabel.TextSize = 19 end
	if kind == "alert" then
		-- gold, matching the legacy tile's alert and the kit's coin golds
		local grad = b:FindFirstChildOfClass("UIGradient")
		if grad then grad.Color = BADGE_GOLD
		else b.BackgroundColor3 = Color3.fromHex("#F5B62E") end
	end
	b.AnchorPoint = Vector2.new(1, 0)
	b.Position = UDim2.new(1, -12, 0, -6)
	b.ZIndex = T.zindex.rail + 15
	-- (no UI.hardShadow: the badge is AutomaticSize.X with an offset-0 Size,
	-- and hardShadow copies that Size literally -- the shadow rendered 0px
	-- wide, i.e. never. Pre-existing; the kit's "hard shadow 0 3" spec needs
	-- a sizing fix in Builders first. Dropping the dead call stops orphaning
	-- one invisible frame per badge. Review catch.)
	railBadges[id] = b
end

if type(SideRail.attachBadgeSurface) == "function" then
	for id, tileName in pairs(CLAIM_SOURCE) do
		if railItems[id] then
			SideRail.attachBadgeSurface(tileName, function(kind, n)
				paintBadge(id, kind, n)
			end)
		end
	end
end

---------------------------------------------------------------- panel control
local function updateActiveGlow()
	local rb = rebirthPanel()
	for id, item in pairs(railItems) do
		if id == "rebirth" then
			-- rebirth's open state lives on the legacy panel, not currentPanelId
			item.glow.Visible = (rb ~= nil and rb.Visible)
		else
			item.glow.Visible = (id == currentPanelId)
		end
	end
end

-- The legacy panel opens/closes outside openPanel/closePanel, so the rebirth
-- glow rides the panel's own Visible signal instead.
task.spawn(function()
	local ui = playerGui:WaitForChild("RebirthUI", 10)
	local panel = ui and ui:WaitForChild("RebirthPanel", 5)
	if not panel then return end
	panel:GetPropertyChangedSignal("Visible"):Connect(updateActiveGlow)
	updateActiveGlow()
end)

-- Bug D fix (ui-overhaul checkpoint-1 fix wave): kit-styled "COMING SOON"
-- placeholder mounted into `host` when openPanel(id) is called for an id
-- with no registered module yet (GameHUDPanels is empty this checkpoint --
-- panels arrive in later tasks). Destroyed on close (closePanel) or the
-- instant a later openPanel call swaps to a different id -- never left
-- orphaned in host.
local placeholderWrapper = nil
local placeholderFrame = nil
local placeholderForId = nil

-- Bug D2 fix (placeholder shadow leak, round-2): UI.panel() parents its
-- HardShadow as a SIBLING of the panel Frame (into whatever `parent`
-- UI.panel was called with -- see UIKit.Builders' UI.hardShadow:
-- `sh.Parent = frame.Parent`), not as a child of the panel.
-- destroyPlaceholder() used to destroy only placeholderFrame (the panel),
-- leaving that sibling shadow behind every time -- one orphaned
-- `HardShadow` accumulating in `host` per open/close cycle
-- (task-4-report.md Round-2 Check D). Fix: destroy the wrapper Frame that
-- now hosts both (see buildPlaceholder below), taking panel + shadow
-- together in one call.
local function destroyPlaceholder()
	if placeholderWrapper then
		placeholderWrapper:Destroy()
		placeholderWrapper = nil
		placeholderFrame = nil
		placeholderForId = nil
	end
end

local function buildPlaceholder(id)
	local screenName = ID_TO_SCREEN[id] or id
	local width = T.size.panelWidth[screenName] or 700

	-- Bug D2 fix: mount the placeholder inside a transparent, full-size
	-- wrapper Frame parented into `host`, and build UI.panel() INSIDE that
	-- wrapper instead of directly into `host` -- the panel and its sibling
	-- HardShadow (see UI.panel/UI.hardShadow in UIKit.Builders) both land
	-- inside the wrapper this way, so destroyPlaceholder() destroying the
	-- wrapper takes both with it.
	local wrapper = Instance.new("Frame")
	wrapper.Name = "PlaceholderWrapper"
	wrapper.Size = UDim2.fromScale(1, 1)
	wrapper.BackgroundTransparency = 1
	wrapper.ZIndex = host.ZIndex
	wrapper.Parent = host
	placeholderWrapper = wrapper

	local panel = UI.panel(wrapper, UDim2.fromOffset(width, 566))
	panel.Name = "PlaceholderPanel"
	panel.AnchorPoint = Vector2.new(0.5, 0.5)
	panel.Position = UDim2.fromScale(0.5, 0.5)

	local list = Instance.new("UIListLayout")
	list.FillDirection = Enum.FillDirection.Vertical
	list.HorizontalAlignment = Enum.HorizontalAlignment.Center
	list.VerticalAlignment = Enum.VerticalAlignment.Center
	list.SortOrder = Enum.SortOrder.LayoutOrder
	list.Padding = UDim.new(0, 16)
	list.Parent = panel

	local title = UI.label(panel, id, "panelTitle", T.color.white)
	title.Name = "PanelTitleLabel"
	title.LayoutOrder = 1
	title.TextXAlignment = Enum.TextXAlignment.Center

	local comingSoon = UI.label(panel, "COMING SOON", "buttonL", T.color.white)
	comingSoon.Name = "ComingSoonLabel"
	comingSoon.LayoutOrder = 2
	comingSoon.TextXAlignment = Enum.TextXAlignment.Center

	return panel
end

function openPanel(id)
	pcall(SoundKit.play, "panelOpen", nil, { volume = CLICK_VOLUME })
	closeGen += 1 -- FIX F3: invalidate any in-flight closePanel hide callback
	local mod = panelModules[id]

	-- Bug D fix: the shell (host/scrim/currency-hide/single-open) must engage
	-- even when no panel module is registered for `id` yet -- every id used to
	-- early-return before ANY of this ran, silently disabling both this
	-- checkpoint's expected "empty shell opens" feedback and SideRail's
	-- legacy-closing behaviour (both hang off host's Visible transition -- see
	-- the watcher near the bottom of this file). Only the panel CONTENT is
	-- conditional now; the shell state changes below are unconditional.
	--
	-- Review catch (2026-08-04, panel-restyle round): hide EVERY other panel
	-- unconditionally, not just panelInstances[currentPanelId]. closePanel
	-- nils currentPanelId synchronously and DEFERS its wrapper hide behind
	-- closeGen; an openPanel within that 0.12s window bumps closeGen (killing
	-- the deferred hide) while this branch used to skip (currentPanelId
	-- already nil) -- stranding the previous wrapper Visible=true forever:
	-- panels stacked, and DailyPanel's backdrop blur + countdown never tore
	-- down (their teardown rides wrapper.Visible). Iterating everything is
	-- idempotent and closes the race whatever the bookkeeping says.
	for otherId, inst in pairs(panelInstances) do
		if otherId ~= id and inst.Visible then
			inst.Visible = false
		end
	end
	if placeholderForId and placeholderForId ~= id then
		destroyPlaceholder()
	end

	local frame
	if mod then
		if not panelInstances[id] then
			local ok, built = pcall(mod.Build, ctx)
			if not ok or typeof(built) ~= "Instance" then return end
			built.Parent = host
			built.Visible = false
			panelInstances[id] = built
		end
		frame = panelInstances[id]
	else
		if placeholderForId ~= id then
			destroyPlaceholder()
			placeholderFrame = buildPlaceholder(id)
			placeholderForId = id
		end
		frame = placeholderFrame
	end

	currentPanelId = id
	state.screen = ID_TO_SCREEN[id] or id
	host.Visible = true

	frame.Visible = true
	local scale = frame:FindFirstChildOfClass("UIScale")
	if not scale then
		scale = Instance.new("UIScale")
		scale.Parent = frame
	end
	scale.Scale = 0.92
	TweenService:Create(scale, T.tween.panelOpen, { Scale = 1 }):Play()

	scrim.Visible = true
	scrim.BackgroundTransparency = 1
	TweenService:Create(scrim, T.tween.scrim, { BackgroundTransparency = T.scrimAlpha }):Play()

	updateActiveGlow()
end

function closePanel()
	if not currentPanelId then return end   -- guard FIRST: no sound for a no-op close
	pcall(SoundKit.play, "panelClose", nil, { volume = CLICK_VOLUME })
	closeGen += 1 -- FIX F3: bump on every close too, so a close->reopen->close
	-- sequence never lets an earlier close's delayed callback act on a later state
	local myCloseGen = closeGen
	local id = currentPanelId
	local frame = panelInstances[id]
	if not frame and placeholderForId == id then
		frame = placeholderFrame
	end
	currentPanelId = nil
	state.screen = "none"
	currencyCluster.Visible = true
	updateActiveGlow()

	if frame then
		local scale = frame:FindFirstChildOfClass("UIScale")
		if scale then
			TweenService:Create(scale, T.tween.panelClose, { Scale = 0.95 }):Play()
		end
	end
	TweenService:Create(scrim, T.tween.panelClose, { BackgroundTransparency = 1 }):Play()

	-- FIX F3 (2026-07-30 fix wave): this callback used to run unconditionally,
	-- so a close->reopen within panelClose.Time (e.g. a rail double-click) hid
	-- the freshly reopened panel out from under the player -- openPanel bumps
	-- closeGen too, so myCloseGen goes stale the instant any open/close call
	-- happens after this one, and the callback no-ops instead of touching
	-- state that no longer belongs to it.
	task.delay(T.tween.panelClose.Time, function()
		if myCloseGen ~= closeGen then return end
		if frame then frame.Visible = false end
		if placeholderForId == id then
			destroyPlaceholder()
		end
		if not currentPanelId then
			scrim.Visible = false
			host.Visible = false
		end
	end)
end

function setBadge(id, n)
	-- ctx contract unchanged (numeric): panels keep calling this. Kind-aware
	-- paints from SideRail's reporters reach paintBadge directly via
	-- attachBadgeSurface; both paths share the one renderer above the
	-- panel-control section.
	paintBadge(id, (n and n > 0) and "count" or "none", n)
end

function pillAnchor(which)
	local pill = (which == "gem") and gemPill or coinPill
	if not pill then return Vector2.new(0, 0) end
	return pill.AbsolutePosition + pill.AbsoluteSize / 2
end

ctx.Tokens = T
ctx.Builders = UI
ctx.remotes = remotes
ctx.host = host
ctx.openPanel = openPanel
ctx.closePanel = closePanel
ctx.setBadge = setBadge
ctx.pillAnchor = pillAnchor
ctx.state = state

---------------------------------------------------------------- panel registration
-- Every ModuleScript dropped into the sibling GameHUDPanels folder is
-- required at startup. { Id, Build } expected; anything else (or a require
-- that errors) is skipped silently -- the folder is empty until later tasks.
local panelsFolder = script.Parent:WaitForChild("GameHUDPanels")
for _, m in ipairs(panelsFolder:GetChildren()) do
	if m:IsA("ModuleScript") then
		local ok, mod = pcall(require, m)
		if ok and type(mod) == "table" and type(mod.Build) == "function" and type(mod.Id) == "string" then
			panelModules[mod.Id] = mod
		end
	end
end

---------------------------------------------------------------- ESC
UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then return end
	if input.KeyCode == Enum.KeyCode.Escape then
		-- the rebirth surface is a legacy panel outside closePanel's world;
		-- without this, ESC would ignore it (RebirthClient never wired ESC)
		local rb = rebirthPanel()
		if rb and rb.Visible then
			rb.Visible = false
			return
		end
		closePanel()
	end
end)

---------------------------------------------------------------- SideRail single-open integration
-- Legacy surfaces (wheel, egg shop, fusion, shop/sell, daily, quests, season,
-- index, backpack, merchant...) and the new HUD close one another.
SideRail.registerPanel(host)

-- SideRail's own registerPanel watcher force-closes OTHER registered panels
-- the instant one of them opens -- including this host. When that happens
-- our bookkeeping (currentPanelId, currency cluster, active glow) needs to
-- resync even though it wasn't our own closePanel() that hid it.
host:GetPropertyChangedSignal("Visible"):Connect(function()
	if host.Visible or not currentPanelId then return end
	local id = currentPanelId
	local frame = panelInstances[id]
	if frame then frame.Visible = false end
	-- Bug D fix: SideRail's registry can force-close `host` (e.g. legacy egg
	-- shop opening) without ever going through closePanel() -- the placeholder
	-- needs the same cleanup here so it never survives host being hidden out
	-- from under it.
	if placeholderForId == id then
		destroyPlaceholder()
	end
	scrim.Visible = false
	currentPanelId = nil
	state.screen = "none"
	currencyCluster.Visible = true
	updateActiveGlow()
end)

-- Hide SideRail's own visual rail PERMANENTLY: its tiles stay functional
-- (registerPanel/single-open still runs for legacy panels) but invisible --
-- panel opening now goes through the new rail above only. No exported
-- no-op-safe call exists on SideRail for this, so this reaches into
-- PlayerGui.SideRailUI.LeftRail directly. SideRail's own updateRailVisibility
-- flips this frame back to Visible=true every time a registered panel closes
-- (anyOpen == false), so a one-shot Visible=false is not enough -- a watcher
-- re-hides it every time that happens. Disconnects nothing inside SideRail.
task.spawn(function()
	local sideRailUI = playerGui:WaitForChild("SideRailUI", 5)
	local leftRail = sideRailUI and sideRailUI:WaitForChild("LeftRail", 5)
	if not leftRail then return end
	leftRail.Visible = false
	leftRail:GetPropertyChangedSignal("Visible"):Connect(function()
		if leftRail.Visible then leftRail.Visible = false end
	end)
end)

---------------------------------------------------------------- legacy retirements
-- Runtime property sets, all WaitForChild-timeout + nil-guarded -- a
-- collaborator may have renamed or removed any of these, and a missing
-- legacy gui must never hard-error the new HUD.
local function retire(container, name, timeout)
	if not container then return end
	local inst = container:WaitForChild(name, timeout or 5)
	if not inst then return end
	if inst:IsA("ScreenGui") then
		inst.Enabled = false
	elseif inst:IsA("GuiObject") then
		inst.Visible = false
	end
end

-- HUD RESCUE (2026-07-31): every retirement now gets its OWN thread. They
-- used to run in sequence inside a single one, where a WaitForChild(name, 5)
-- for a gui that does not exist blocks the whole chain for the full timeout
-- -- and IndexUI genuinely does not exist in this build (verified live: no
-- IndexUI under PlayerGui, IndexClient parents into MainUI). So the legacy
-- cash pill, the old gem HUD and the old backpack button sat on top of the
-- new HUD for 5+ seconds after EVERY join; it showed up in back-to-back join
-- captures. Independent threads mean a missing gui only ever costs its own
-- thread the wait.
local function retireAsync(container, name, timeout)
	task.spawn(retire, container, name, timeout)
end

-- Daily / Quests / Season each own a ScreenGui.
retireAsync(playerGui, "DailyUI")
retireAsync(playerGui, "QuestUI")
retireAsync(playerGui, "SeasonUI")
-- IndexUI: known absent today (see above); kept per the brief in case a
-- future rename reintroduces it, and nil-guarded so absence is a no-op.
retireAsync(playerGui, "IndexUI")
retireAsync(playerGui, "DarrelHUD")

-- Backpack's panel/open-button are Frames inside MainUI, not their own
-- ScreenGui (confirmed by reading BackpackClient) -- MainUI itself stays up
-- (hotbar, cash pill host) and only these Frames retire.
task.spawn(function()
	local mainUI = playerGui:WaitForChild("MainUI", 5)
	if not mainUI then return end
	retireAsync(mainUI, "BackpackFrame")
	retireAsync(mainUI, "BackpackOpen")
	retireAsync(mainUI, "CashFrame")
end)
