-- CatchRevealClient: turns a catch into a reveal.
--
-- Deliberately thin. All the presentation lives in CatchReveal (the screen-space card)
-- and CatchFX (the burst around the player); this only decides WHETHER to show one,
-- which is exactly the decision the phase-2 Robux upgrade needs to change.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CatchReveal = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("CatchReveal"))
local PullCeremony = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("PullCeremony"))
-- Size-mutated catches get a cutscene of the creature rising out of the water BEFORE the
-- ordinary ceremony. Storyboard beats B1-B3, which the Catch Ceremony plan specified but
-- never built. It returns false and costs nothing on an ordinary catch.
local MassiveEmergence = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("MassiveEmergence"))
local BrainrotConfig = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("BrainrotConfig"))
-- within-tier odds for the ceremony: weights sum to 100,000 per tier, so
-- "1 in N of its tier" with N = 100000/Weight is HONEST, not theater
local weightByName, voiceByName = {}, {}
for _, e in ipairs(BrainrotConfig) do
	weightByName[e.Name] = e.Weight
	-- optional per-creature voice line; nil for every entry today
	if type(e.VoiceId) == "string" and e.VoiceId ~= "" then voiceByName[e.Name] = e.VoiceId end
end
local CatchFX = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("CatchFX"))
local SoundKit = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("SoundKit"))

-- The Massive catch cinematic, required FAIL-SOFT -- the same shape ThrowHandler uses
-- for this folder on the server, and for the same reason: deleting or breaking
-- CatchCinematic must not take the ordinary reveal chain down with it. Both stay nil if
-- anything here throws, and every use below is guarded, so a missing folder leaves this
-- script behaving exactly as it did before the cinematic existed. Bounded WaitForChild
-- rather than an unbounded one: Modules is already resolved by the requires above, so
-- five seconds is generous, and a timeout costs a nil, never a hang.
local CinBridge, CinConfig
do
	local ok, bridge, cfg = pcall(function()
		local folder = ReplicatedStorage.Modules:WaitForChild("CatchCinematic", 5)
		return require(folder:WaitForChild("Bridge", 5)), require(folder:WaitForChild("Config", 5))
	end)
	if ok and type(bridge) == "table" then
		CinBridge = bridge
		CinConfig = cfg
	else
		warn("[CatchRevealClient] CatchCinematic unavailable (" .. tostring(bridge) .. ") -- ordinary reveals only")
	end
end

local remotes = ReplicatedStorage:WaitForChild("Remotes")
local throwResult = remotes:WaitForChild("ThrowResult")

-- REMOVED: the Legendary "ping". It was a raw Sound instance created here with a
-- hardcoded asset id, played through SoundService:PlayLocalSound at volume 0.65 --
-- outside SoundKit entirely, and roughly double the level of the tuned catch ladder
-- (0.13 to 0.54), which is why it stuck out. Legendary now gets its rung of that
-- ladder like every other tier.

-- The catcher's own cue, per tier. Mirrors the ladder in RareCatchClient because
-- these are the tiers that ladder never reaches: RareCatch is only broadcast for
-- Secret / God / Rainbow / Glitched (see ThrowHandler.revealCatch, ~line 890), so
-- Common through Mythic previously landed in total silence for the catcher.
local TIER_SFX = {
	Common    = { { sound = "catchCommon",   volume = 0.13 } },
	Uncommon  = { { sound = "catchUncommon", volume = 0.17 } },
	Rare      = { { sound = "catchRare",     volume = 0.21 } },
	Epic      = { { sound = "catchEpic",     volume = 0.25 } },
	Legendary = { { sound = "catchLegend",   volume = 0.30 },
	              { sound = "catchSparkle",  volume = 0.14, delay = 0.07 } },
	Mythic    = { { sound = "catchMythic",   volume = 0.34 },
	              { sound = "catchSparkle",  volume = 0.18, delay = 0.06 } },
}

-- IN SYNC WITH THE SERVER. ThrowHandler broadcasts RareCatch for exactly these, and
-- RareCatchClient plays the ladder for them at full level. Playing here as well would
-- stack two copies of the same sting on the biggest catches in the game.
local function isBroadcast(result)
	return result.Rarity == "Secret" or result.Rarity == "God"
		or result.Mutation == "Rainbow" or result.Mutation == "Glitched"
end

local function playTierCue(result)
	local layers = TIER_SFX[result.Rarity]
	if not layers then return end
	for _, layer in ipairs(layers) do
		if (layer.delay or 0) <= 0 then
			SoundKit.play(layer.sound, nil, { volume = layer.volume })
		else
			task.delay(layer.delay, function()
				SoundKit.play(layer.sound, nil, { volume = layer.volume })
			end)
		end
	end
end

-- PHASE 2 SEAM, filled (2026-08-04 v2): Settings > Skip Catch Animation --
-- the free per-rarity version of the phase-2 plan ("the player's chosen
-- rarities", exactly as this comment always said). SettingsPanel writes one
-- boolean attribute per tier (SkipRevealCommon .. SkipRevealGod); read at
-- time of use, so a mid-session change covers the very next catch. The
-- burst + tier cue above the gate still play, and ClientMain shows its
-- ThrowResult text card for skipped rarities, so every catch is still
-- announced -- picked rarities just take ~3s of corner text instead of an
-- up-to-9s takeover.
--
-- Skipping an ANIMATION is a pure presentation choice, so the client may own it
-- -- a client that lies about it gains nothing. The auto-sell half of that
-- upgrade is NOT the same and must never live here: a client that can say "sell
-- this catch" can say it about anything. Auto-sell belongs server-side in
-- ThrowHandler.revealCatch behind a verified MarketplaceService check.
local player = Players.LocalPlayer
local function shouldReveal(result)
	return player:GetAttribute("SkipReveal" .. tostring(result.Rarity)) ~= true
end

-- Extracted VERBATIM from the OnClientEvent handler below, so the cinematic's
-- after-flow can build the same ceremony payload without replaying the burst and the
-- tier cue. tierCuePlayed defaults to false, which is the truth on the cinematic path:
-- nothing above the gate ran, by design -- no burst or tier cue may pollute the bonk.
local function buildPayload(result, tierCuePlayed)
	local weight = weightByName[result.BrainrotName]
	return {
		Name = result.BrainrotName,
		Rarity = result.Rarity,
		RarityColor = result.RarityColor,
		Mutation = result.Mutation,
		Size = result.Size,
		SplashPos = result.SplashPos,
		Serial = result.Serial,
		Exists = result.Exists,
		OddsN = weight and math.max(2, math.floor(100000 / weight + 0.5)) or nil,
		TierCuePlayed = tierCuePlayed == true,
		VoiceId = voiceByName[result.BrainrotName],   -- nil unless authored
	}
end

-- The whole ordinary chain, extracted unchanged from the handler so the cinematic can
-- DEFER it (and rerun it wholesale if the cinematic dies). Same order, same pcalls,
-- same comments.
local function ordinaryReveal(result)
	-- Burst first: it reads as the catch LANDING, so it should not wait on the card.
	-- pcall for the same reason as the reveal -- an effect must never break a catch.
	pcall(CatchFX.play, {
		Rarity = result.Rarity,
		Color = result.RarityColor,
		Mutation = result.Mutation,
	})

	-- Recorded so PullCeremony does not play the SAME tier cue a second time.
	-- TIER_SFX has no Secret/God rungs, and broadcasts are skipped anyway, so on
	-- those tiers this stays false and the ceremony carries the lead itself.
	local tierCuePlayed = false
	if not isBroadcast(result) then
		pcall(playTierCue, result)
		tierCuePlayed = TIER_SFX[result.Rarity] ~= nil
	end

	if not shouldReveal(result) then return end

	-- pcall: a broken reveal must never break the catch that produced it.
	local payload = buildPayload(result, tierCuePlayed)
	-- A Huge/Massive rises out of the lake first. Deliberately BEFORE the takeover: the
	-- creature has to come out of the water the player actually threw into, and the
	-- takeover blacks the world out. pcall + fail-soft, so a broken cutscene still lets
	-- the ordinary reveal through.
	pcall(MassiveEmergence.play, payload)

	-- Epic+ gets the full Pull ceremony (takeover / odds climb / burst / stamp);
	-- lower tiers keep the fast reveal untouched -- respect the grind.
	pcall(PullCeremony.play, payload)
end

throwResult.OnClientEvent:Connect(function(result)
	if type(result) ~= "table" or type(result.BrainrotName) ~= "string" then return end

	-- A cinematic-owned catch: the takeover IS the reveal. Adopt hands the
	-- authoritative result to the sequencer (covers reveal-time fallback swaps)
	-- and defers/replaces the ordinary chain. Fail-soft: if the cinematic dies,
	-- onDone(false) reruns this exact ordinary path. pcall'd end to end -- a
	-- broken bridge must cost this catch nothing at all.
	local adopted = false
	if CinBridge then
		local okAdopt, res = pcall(CinBridge.tryAdopt, result)
		if not okAdopt then
			warn("[CatchRevealClient] cinematic adopt errored: " .. tostring(res))
		end
		adopted = okAdopt and res == true
	end
	if adopted then
		local okHook = pcall(CinBridge.onDone, function(ok)
			if not ok then ordinaryReveal(result) return end
			local after = workspace:GetAttribute("CinematicCeremonyAfter")
			if after == nil then after = CinConfig and CinConfig.RUN_PULL_CEREMONY_AFTER end
			if after then pcall(PullCeremony.play, buildPayload(result)) end
		end)
		-- Registering the callback is the only thing that can ever un-defer this
		-- reveal. If even that failed, the catch would be silently eaten -- so fall
		-- straight through to the ordinary chain instead.
		if okHook then return end
	end

	ordinaryReveal(result)
end)
