--!strict
-- CatchCinematic.Types — shared type definitions for the Massive catch cinematic.
-- Consumed by Sequencer/CinematicClient/ThrowHandler (comment-referenced there).

export type CinematicPayload = {
	UserId: number,
	BrainrotName: string,
	Rarity: string,
	RarityColor: Color3,
	Mutation: string?,
	Size: string,
	RockId: string?,
	RockColor: Color3?,
	EndPos: Vector3,
	SurfaceY: number,
	TotalTime: number,
	NContacts: number,
	SegTime: number,
	Seed: number,
}

return {}
