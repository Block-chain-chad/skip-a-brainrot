--!strict
-- CatchCinematic.RockRig -- the skipping stone's post-bonk choreography: an
-- absurdly-hanging ricochet arc, a slow hover, a fall back down onto the
-- player's head (the "second bonk" at secondBonkT), a plink pause, then a
-- chaotic tumble back down into the water it came from, then hidden.
--
-- Rock:update(t, headPos) is a PURE function of cinematic time t (seconds since
-- the sequence started): calling it twice with the same (t, headPos) always
-- produces the same model CFrame and the same hidden/visible state, regardless
-- of call order or history. All per-instance variance (ricochet lateral drift
-- direction/magnitude, spin axis) is drawn from the injected `rng: Random`
-- exactly ONCE, in RockRig.new -- never per-frame, never via math.random.
--
-- cfg is Config.ROCK, optionally carrying three extra timing fields the
-- Sequencer should merge in (same pattern Task 3's ScreenShake.new(cfg).shakeMult
-- established -- see that module's header and Task 3's report "Concern #1"):
--   apexT          -- default 3.2, matches Config.BEATS.dread's t1 (end of dread)
--   secondBonkT    -- default 5.6, should be Config.SECOND_BONK_T
--   descentSeconds -- default 1.4, time spent falling from hover down to headPos
-- Built-in defaults match this task's brief exactly, so passing bare Config.ROCK
-- today still produces the documented choreography; Task 7 only needs to merge
-- these in if it ever wants apexT/secondBonkT to track a tuned Config.BEATS or
-- Config.SECOND_BONK_T that drifts from these defaults.
--
-- Choreography (derived from the brief's "0->~3.2s ... slow sine hover at top,
-- descent to headPos arriving at secondBonkT, plink pause, tumble over
-- tumbleSeconds, then hidden"):
--   [0, apexT]                      ricochet up, flattened-apex curve (absurd hang)
--   (apexT, hoverEndT]              slow sine hover at the apex (bob returns to 0
--                                    at both ends -- HOVER_PERIOD is chosen so the
--                                    hover window is one whole period by default)
--   (hoverEndT, secondBonkT]        descent to headPos, accelerating (gravity feel)
--   (secondBonkT, secondBonkT+plinkPauseSeconds]           held at headPos (plink)
--   (..., ...+tumbleSeconds]        tumble: a little hop, then falls back to bonkPos
--   after that                      hidden (Transparency 1, emitters/lights off)
--
-- The rock model comes from RockDesign.Build(rockId, rockColor) -- unchanged,
-- reused verbatim -- and is driven entirely by Model:PivotTo (never welds), so
-- its own Fx-kit particles/lights/trail (if any) ride along for free.

export type RockRigCfg = {
	ricochetApex: number?,
	ricochetLateral: number?,
	spinRadPerSec: number?,
	plinkPauseSeconds: number?,
	tumbleSeconds: number?,
	apexT: number?,
	secondBonkT: number?,
	descentSeconds: number?,
}

local RockRig = {}
RockRig.__index = RockRig

export type Rock = typeof(setmetatable(
	{} :: {
		_cfg: RockRigCfg,
		_stage: Folder,
		_bonkPos: Vector3,
		_rng: Random,
		_model: Model,
		_origTransparency: { [BasePart]: number },
		_driftDir: Vector3,
		_driftDist: number,
		_spinAxis: Vector3,
		_hidden: boolean,
	},
	RockRig
))

local FALLBACK_HEAD_OFFSET = Vector3.new(0, 5, -8) -- used only if headPos is nil
local HOVER_BOB_STUDS = 0.6
-- Seconds per hover sine cycle. Chosen so bob(0) == bob(hoverEndT-apexT) == 0
-- when the default apexT/secondBonkT/descentSeconds are used (hover window = 1.0s
-- = one whole period). A caller-overridden window that isn't a whole multiple of
-- this just means a sub-stud discontinuity at the hover->descent handoff, not a
-- correctness bug.
local HOVER_PERIOD = 1.0
local TUMBLE_HOP_STUDS = 2.5

local function flattenedApex(p: number): number
	p = math.clamp(p, 0, 1)
	return 1 - (1 - p) ^ 2.4
end

function RockRig.new(
	cfg: RockRigCfg,
	stage: Folder,
	rockId: string?,
	rockColor: Color3?,
	bonkPos: Vector3,
	rng: Random
): Rock
	local RockDesign = require(script.Parent.Parent.RockDesign)

	local model = RockDesign.Build(rockId, rockColor)
	model.Parent = stage

	local origTransparency: { [BasePart]: number } = {}
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			origTransparency[d] = d.Transparency
		end
	end

	-- Drawn ONCE from rng: deterministic per seed, reused by every update() call.
	-- driftDist is scaled into [0.4, 1.0] * ricochetLateral so every catch gets
	-- some sideways drift, never exactly zero (a dead-straight ricochet reads as
	-- a bug, not a choice).
	local driftAngle = rng:NextNumber() * math.pi * 2
	local driftDir = Vector3.new(math.cos(driftAngle), 0, math.sin(driftAngle))
	local driftDist = (0.4 + rng:NextNumber() * 0.6) * (cfg.ricochetLateral or 6)
	local spinAxis = Vector3.new(rng:NextNumber() * 2 - 1, rng:NextNumber() * 2 - 1, rng:NextNumber() * 2 - 1)
	if spinAxis.Magnitude < 1e-3 then
		spinAxis = Vector3.new(0, 1, 0)
	else
		spinAxis = spinAxis.Unit
	end

	local self = setmetatable({
		_cfg = cfg,
		_stage = stage,
		_bonkPos = bonkPos,
		_rng = rng,
		_model = model,
		_origTransparency = origTransparency,
		_driftDir = driftDir,
		_driftDist = driftDist,
		_spinAxis = spinAxis,
		_hidden = false,
	}, RockRig)
	return (self :: any) :: Rock
end

function RockRig:_hoverEndT(): number
	local cfg = self._cfg
	local secondBonkT = cfg.secondBonkT or 5.6
	local descentSeconds = math.max(cfg.descentSeconds or 1.4, 0.1)
	return secondBonkT - descentSeconds
end

-- Idempotent (no-op if already in the requested state) so update() can call it
-- unconditionally every frame without repeatedly walking every descendant.
function RockRig:_setHidden(hidden: boolean)
	if self._hidden == hidden then
		return
	end
	self._hidden = hidden
	for _, d in ipairs(self._model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Transparency = hidden and 1 or (self._origTransparency[d] or 0)
		elseif d:IsA("ParticleEmitter") or d:IsA("Trail") or d:IsA("PointLight") then
			d.Enabled = not hidden
		end
	end
end

function RockRig:update(t: number, headPos: Vector3?)
	local cfg = self._cfg
	local apex = cfg.ricochetApex or 120
	local apexT = math.max(cfg.apexT or 3.2, 0.1)
	local spin = cfg.spinRadPerSec or 9.0
	local plinkPause = math.max(cfg.plinkPauseSeconds or 0.35, 0)
	local tumbleSeconds = math.max(cfg.tumbleSeconds or 0.8, 0.05)
	local secondBonkT = cfg.secondBonkT or 5.6
	local hoverEndT = self:_hoverEndT()
	local plinkEndT = secondBonkT + plinkPause
	local tumbleEndT = plinkEndT + tumbleSeconds

	local target = headPos or (self._bonkPos + FALLBACK_HEAD_OFFSET)
	local bonk = self._bonkPos
	local hoverPos = bonk + Vector3.new(0, apex, 0) + self._driftDir * self._driftDist

	local pos: Vector3
	if t <= apexT then
		local p = t / apexT
		local h = apex * flattenedApex(p)
		pos = bonk + Vector3.new(0, h, 0) + self._driftDir * self._driftDist * p
	elseif t <= hoverEndT then
		local bobT = t - apexT
		local bob = HOVER_BOB_STUDS * math.sin((bobT / HOVER_PERIOD) * math.pi * 2)
		pos = hoverPos + Vector3.new(0, bob, 0)
	elseif t <= secondBonkT then
		local dp = math.clamp((t - hoverEndT) / math.max(secondBonkT - hoverEndT, 1e-3), 0, 1)
		local ease = dp * dp -- accelerating fall, gravity feel
		pos = hoverPos:Lerp(target, ease)
	elseif t <= plinkEndT then
		pos = target
	elseif t <= tumbleEndT then
		local tp = math.clamp((t - plinkEndT) / tumbleSeconds, 0, 1)
		local hop = TUMBLE_HOP_STUDS * math.sin(tp * math.pi)
		pos = target:Lerp(bonk, tp) + Vector3.new(0, hop, 0)
	else
		pos = bonk
	end

	local spinCF = CFrame.fromAxisAngle(self._spinAxis, spin * t)
	self._model:PivotTo(CFrame.new(pos) * spinCF)
	self:_setHidden(t > tumbleEndT)
end

function RockRig:cleanup()
	if self._model and self._model.Parent then
		self._model:Destroy()
	end
end

return RockRig
