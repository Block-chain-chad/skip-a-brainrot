--!strict
-- CatchCinematic.Sequencer -- THE CONDUCTOR. Everything Tasks 1-6 built (CameraRig,
-- ScreenShake, WaterFX, RockRig, BrainrotRig, PostFX, AudioBus, HypeUI) is composed
-- here into the 17.9s Massive catch cinematic and its 4.3s trimmed Huge cut.
--
-- ================================ BEAT MAP ================================
--   t (s)        beat        enter fn         per-frame fn      exit fn
--   0.00-0.35    bonk        enterBonk        --                --
--   0.35-1.60    travel      enterTravel      --                --
--   1.60-5.60    dread       enterDread       updateDread       --
--   5.60-6.35    silence     enterSilence     --                exitSilence
--   6.35-7.20    eruption    enterEruption    updateEruption    --
--   7.20-13.70   rise        enterRise        updateRise        --
--   13.70-16.20  hype        enterHype        updateHype        --
--   16.20-17.90  handoff     enterHandoff     updateHandoff     --
--
-- Run EVERY frame regardless of beat, in this order (see stepInner):
--   1. clock advance + the pre-eruption result hold      5. rock:update(t) (pure in t)
--   2. cancel deadline check                             6. the second bonk one-shot
--   3. ThrowResult name reconciliation -> swapModel      7. beat enter/exit dispatch
--   4. skip poll + skip/cancel fade state machines       8. end-of-timeline check
--
-- The trimmed variant (Config.HUGE_TRIM) simply drops `silence` and `hype` and
-- re-times the rest; the SAME enter/update fns run for the beats it keeps, and the
-- rock's apexT/secondBonkT/descentSeconds are re-derived from the trimmed bounds
-- (see rockTimings) so the second bonk still lands inside the rise beat.
--
-- ================================ TIMESCALE ================================
-- Config.timescale() is a SPEED multiplier -- Config's own header says
-- "0.25 = quarter speed", i.e. 0.25 makes everything take FOUR TIMES LONGER in wall
-- time. Exactly two derived numbers are used in this module, and nothing else:
--   run.speed   = Config.timescale()   -- cinematic seconds per real second
--   run.stretch = 1 / run.speed        -- real seconds per cinematic second
-- The rules, applied without exception:
--   * the conductor advances the master clock by  dt * run.speed
--   * every duration handed to a module that runs on its OWN wall clock
--     (CameraRig flyTo/orbit/punchFOV/returnToPlayer, PostFX hypeOn/easeBack,
--     WaterFX cascade, BrainrotRig revealColors/compressAndStreak, AudioBus fades)
--     is passed as  cinematicSeconds * run.stretch
--   * HypeUI's 5th constructor arg is a DURATION multiplier, not a speed one -- its
--     own header: "every wall-clock loop's elapsed-time computation divides by it".
--     That is the INVERSE of Config.timescale(), so HypeUI gets run.stretch. Set
--     CinematicTimescale = 0.25 and the beats, the module durations and HypeUI's
--     bursts all stretch 4x together, which is the whole point of the knob.
--   * durations that live INSIDE a module's own cfg -- Config.WATER's
--     domeRiseSeconds/columnSeconds/cascadeSeconds and Config.POSTFX's
--     flashSeconds/easeBackSeconds -- are unreachable from a call site, so buildRun
--     hands those constructors SCALED SHALLOW COPIES (see scaleDurations). Without
--     that, a 0.25x run stretched the beats while the water dome and the eruption
--     flash kept running at 1x, which reads as the effects desynchronising from the
--     cutscene rather than the cutscene slowing down.
--   * Config.CANCEL_TIMEOUT is scaled too. It is a deadline on the GRANT, but what
--     it actually protects is "the timeline must not reach the eruption unresolved",
--     and the timeline is what stretches. Unscaled, a 0.25x run cancelled every
--     single time, mid-dread, before the beats had gone anywhere. Scaled, the cancel
--     always lands at the same PLACE in the cut (t ~= 3.0) at every timescale.
-- Deliberately NOT scaled, because they are input/UX rather than choreography: the
-- SKIP hold duration, the skip/cancel luminance dip, and ScreenShake's trauma decay
-- (sampled on real dt). A slowed-down debug run must not demand a 4x longer press.
-- Accepted un-scaled 1x leftovers, all module-internal constants this module cannot
-- reach without editing those modules: WaterFX's ring lifetimes and godray spin, and
-- BrainrotRig's EYE_TWITCH_SECONDS. All are short one-shots; none carry a beat.
--
-- ================================ LIFECYCLE ================================
-- ONE `run` table per play (deliberately loose-typed -- it is a private bag of
-- per-play state, not a contract), ONE trove (`run.trove`) drained LIFO by
-- cleanup(), and ONE render-step binding as the conductor. cleanup() is wired to
-- every exit: normal end, skip-into-handoff (which still ends normally), cancel
-- timeout, Humanoid.Died, LocalPlayer.CharacterAdded, the conductor's pcall error
-- handler, and TWO watchdogs -- one inside the conductor (covers a stalled beat) and
-- a task.delay backstop (covers the conductor itself no longer being called, which
-- the first one by definition cannot). Both are identity-guarded on `run`, and
-- finish() is idempotent.
--
-- Sequencer.play is BLOCKING (the caller wraps it in task.spawn). Its return value
-- answers exactly one question: "did I take over?" -- false means DECLINED, and the
-- caller must stage its own stock landing. A decline can only happen before anything
-- is parented into the world, so a false return is always safe to fall back from.
-- Because the return only arrives ~10.7s later, the accept/decline answer is ALSO
-- delivered synchronously through opts.onCommit (and run.committed), so a caller
-- never has to infer it from timing. Whether the run then SUCCEEDED is a different
-- flag, reported through Bridge.finish(gen, ok) to whoever adopted the catch.
--
-- SKIP SAFETY: skipping jumps to the handoff, which surfaces, reveals and awards the
-- creature -- so it is gated on the grant having landed. Held early, the dip goes to
-- full dark and WAITS there; if the grant never comes, the cancel path takes over
-- from that same dark frame. A skip can never show a catch the cancel path exists to
-- prevent.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local folder = script.Parent
local Config = require(folder:WaitForChild("Config"))
local CameraRig = require(folder:WaitForChild("CameraRig"))
local ScreenShake = require(folder:WaitForChild("ScreenShake"))
local WaterFX = require(folder:WaitForChild("WaterFX"))
local RockRig = require(folder:WaitForChild("RockRig"))
local BrainrotRig = require(folder:WaitForChild("BrainrotRig"))
local PostFX = require(folder:WaitForChild("PostFX"))
local AudioBus = require(folder:WaitForChild("AudioBus"))
local HypeUI = require(folder:WaitForChild("HypeUI"))
local Bridge = require(folder:WaitForChild("Bridge"))
local Sizes = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("SizeConfig"))

local STAGE_NAME = "CatchCinematicStage"
local FADE_GUI_NAME = "CatchCinematicFade"
-- CameraRig binds its writer at Camera.Value + 1 (= 201). This conductor runs at 199,
-- two slots earlier, so every camera target it sets for a frame is already in place
-- when the rig samples it later in that same frame.
-- PER-RUN *AND* PER-VM UNIQUE. BindToRenderStep keys on the name string, so two
-- bindings sharing one name make an unbind ambiguous -- Roblox warns "removed different
-- functions with same reference name" and one run silently loses its conductor (which
-- only surfaces later, as a backstop-watchdog kill). A run counter alone is unique only
-- WITHIN a Lua VM, and every execute_luau harness gets its own VM whose counter also
-- starts at zero -- so both would bind "...Sequencer1". The salt closes that: it is
-- drawn once per module load, i.e. once per VM. Production is single-VM and the `active`
-- debounce already forbids two concurrent runs, so this is belt-and-braces -- it just
-- costs one GUID.
local BIND_NAME = "CatchCinematicSequencer"
local BIND_PRIORITY = Enum.RenderPriority.Camera.Value - 1
local runCounter = 0
local VM_SALT: string
do
	local ok, guid = pcall(function()
		return game:GetService("HttpService"):GenerateGUID(false)
	end)
	if ok and type(guid) == "string" then
		VM_SALT = string.sub((string.gsub(guid, "%-", "")), 1, 8)
	else
		-- GenerateGUID needs no HTTP permission and does not fail in practice; this is
		-- only so a bind name always exists rather than being nil.
		VM_SALT = string.format("%08x", math.floor(os.clock() * 1e6) % 0xFFFFFFFF)
	end
end

local TRAVEL_BACK_STUDS = 24 -- how far short of the splash the low fly-out parks
local VIEW_DIST_PAD = 10 -- MassiveEmergence's viewDist pad: max(X,Z)*mult + 10
local DIP_MAX = 0.82 -- darkest the skip/cancel luminance dip ever gets (never 1.0)
local PUNCH_HOLD = 0.22 -- cinematic seconds a hype zoom-punch stays pulled in
local WATCHDOG_PAD = 8 -- real seconds of slack before the watchdog kills a run
local CANCEL_DIP_IN, CANCEL_DIP_OUT = 0.15, 0.6 -- real seconds, cancel wind-down dip

-- The cfg fields that are DURATIONS and therefore have to be timescaled before the
-- constructor sees them. Listed explicitly rather than pattern-matched on the name:
-- Config.WATER also holds domeHeightFrac/columnHeightMult/rippleAccel, and silently
-- scaling one of those would be a very quiet geometry bug.
local WATER_DURATION_FIELDS = { "domeRiseSeconds", "columnSeconds", "cascadeSeconds" }
local POSTFX_DURATION_FIELDS = { "flashSeconds", "easeBackSeconds" }

-- Skip input a SPECTATOR's key press must not count as. A bystander is still walking
-- around during someone else's catch, and holding W for half a second is not "get me
-- out of this". The thrower's camera is hijacked, so for them any key really does
-- mean any key -- this exclusion is spectator-only.
local SPECTATOR_SKIP_IGNORED: { [Enum.KeyCode]: boolean } = {
	[Enum.KeyCode.W] = true,
	[Enum.KeyCode.A] = true,
	[Enum.KeyCode.S] = true,
	[Enum.KeyCode.D] = true,
	[Enum.KeyCode.Space] = true,
	[Enum.KeyCode.LeftShift] = true,
	[Enum.KeyCode.RightShift] = true,
}

export type PlayOpts = {
	spectator: boolean?,
	variant: string?,
	-- The Bridge arm this run belongs to (Bridge.arm's return). Thrower runs need it:
	-- it is what scopes result()/finish() to THIS throw instead of whichever arm
	-- happens to be current. Omitted (harness use) => no result plumbing, no cancel.
	bridgeGen: number?,
	-- Called exactly once, synchronously, the instant this run is committed and about
	-- to block. Replaces the old "play cannot yield before returning" comment
	-- invariant with something the caller can actually observe: after task.spawn'ing
	-- play(), the caller knows it was DECLINED iff onCommit has not fired.
	onCommit: (() -> ())?,
}

-- Private per-play state bag. Loose on purpose: it is never handed to a caller.
type Run = { [string]: any }

local Sequencer = {}

local active: Run? = nil

-- ============================== trove ==============================

local function track(run: Run, fn: () -> ())
	table.insert(run.trove, fn)
end

local function drain(run: Run)
	if run.cleaned then
		return
	end
	run.cleaned = true
	-- LIFO: entries are appended as each thing is created, so draining backwards tears
	-- down in the exact reverse of construction order. Construction is stage -> model
	-- -> rock -> water -> audio -> camera -> post -> ui -> skip conns -> kill-switch
	-- conns -> render bind. The fade overlay is created lazily, only when a skip or
	-- cancel first needs one, so it is tracked AFTER the render bind and therefore
	-- drains FIRST. Full drain order: [overlay] -> render bind -> kill-switch conns ->
	-- skip conns -> ui -> post -> camera -> audio -> water -> rock -> model -> stage.
	-- Camera restore therefore happens before the world is torn out from under it, and
	-- the stage folder is destroyed last, as the catch-all for anything a rig leaked
	-- into it.
	for i = #run.trove, 1, -1 do
		local ok, err = pcall(run.trove[i])
		if not ok then
			warn("[Sequencer] cleanup step failed: " .. tostring(err))
		end
	end
	run.trove = {}
end

-- ============================== helpers ==============================

local function beatsFor(variant: string): { any }
	if variant == "trimmed" then
		return Config.HUGE_TRIM
	end
	return Config.BEATS
end

local function beatIndexOf(run: Run, name: string): number?
	for i, b in ipairs(run.beats) do
		if b.name == name then
			return i
		end
	end
	return nil
end

local function beatT0(run: Run, name: string, fallback: number): number
	local i = beatIndexOf(run, name)
	if i then
		return run.beats[i].t0
	end
	return fallback
end

-- The rock's three injected timings, derived from whichever beat table is in play.
-- For the full cut these reproduce Config.SECOND_BONK_T and RockRig's own defaults
-- exactly; for the trimmed cut the second bonk keeps the SAME fractional position
-- inside the rise beat ((5.6-4.5)/(6.5-4.5) = 0.55) so it never falls off the end.
local function rockTimings(run: Run): { [string]: number }
	local dreadIdx = beatIndexOf(run, "dread")
	local riseIdx = beatIndexOf(run, "rise")
	local apexT = dreadIdx and run.beats[dreadIdx].t1 or 3.2
	local secondBonkT: number
	if run.variant == "trimmed" and riseIdx then
		local rise = run.beats[riseIdx]
		secondBonkT = rise.t0 + (rise.t1 - rise.t0) * 0.55
	else
		secondBonkT = Config.SECOND_BONK_T
	end
	local descentSeconds = math.clamp((secondBonkT - apexT) * 0.58, 0.3, 1.4)
	return { apexT = apexT, secondBonkT = secondBonkT, descentSeconds = descentSeconds }
end

local function shallowMerge(base: { [string]: any }, extra: { [string]: any }): { [string]: any }
	local out: { [string]: any } = {}
	for k, v in pairs(base) do
		out[k] = v
	end
	for k, v in pairs(extra) do
		out[k] = v
	end
	return out
end

-- A shallow copy of a cfg table with ONLY the named duration fields multiplied by
-- `stretch`. This is how the debug timescale reaches durations that live inside a
-- module's cfg instead of on a call it makes -- no module is modified, and every
-- untouched field (fractions, multipliers, counts, booleans) is copied verbatim.
local function scaleDurations(base: { [string]: any }, fields: { string }, stretch: number): { [string]: any }
	local out: { [string]: any } = {}
	for k, v in pairs(base) do
		out[k] = v
	end
	if stretch == 1 then
		return out
	end
	for _, k in ipairs(fields) do
		local v = out[k]
		if type(v) == "number" then
			out[k] = v * stretch
		end
	end
	return out
end

local function localHRP(): BasePart?
	local player = Players.LocalPlayer
	local char = player and player.Character
	return (char and char:FindFirstChild("HumanoidRootPart")) :: BasePart?
end

-- Unit horizontal direction from the thrower toward the splash. Both throw lanes
-- face +Z, so that is the fallback when there is no character to measure from.
local function horizToward(surface: Vector3): Vector3
	local hrp = localHRP()
	if hrp then
		local flat = Vector3.new(surface.X - hrp.Position.X, 0, surface.Z - hrp.Position.Z)
		if flat.Magnitude > 1e-3 then
			return flat.Unit
		end
	end
	return Vector3.new(0, 0, 1)
end

-- Refreshed after a swapModel, which replaces both. Read through BrainrotRig's
-- published accessors (added for this: :extents() / :model()) rather than poking its
-- private fields.
local function refreshGeometry(run: Run)
	local brain = run.brain
	if not brain then
		return
	end
	run.model = brain:model()
	run.extents = brain:extents() or Vector3.new(4, 6, 4)
end

local function heroFraming(run: Run): (Vector3, Vector3)
	local cam = Config.CAMERA
	local ext = run.extents :: Vector3
	local width = math.max(ext.X, ext.Z)
	local dist = width * (cam.hoverDistMult or 1.15) + VIEW_DIST_PAD
	local focus = run.surface + Vector3.new(0, ext.Y * (cam.hoverHeightFrac or 0.42), 0)
	local eye = focus - run.horiz * dist + Vector3.new(0, ext.Y * (cam.heroHeightFrac or 0.18), 0)
	return eye, focus
end

local function ensureOverlay(run: Run): Frame?
	if run.overlay then
		return run.overlay
	end
	local player = Players.LocalPlayer
	local pg = player and player:FindFirstChildOfClass("PlayerGui")
	if not pg then
		return nil
	end
	-- Our OWN minimal overlay rather than PostFX: PostFX.flash() is an upward
	-- brightness pulse (and is skipped entirely under reduced motion), while this
	-- is a downward luminance dip that must work on every quality tier, in the
	-- spectator-free cancel path, and even when PostFX was never constructed.
	-- BackgroundTransparency is hand-written per frame -- TweenService silently
	-- no-ops on it in this place (see Config.lua's header).
	local gui = Instance.new("ScreenGui")
	gui.Name = FADE_GUI_NAME
	gui.DisplayOrder = 60
	gui.IgnoreGuiInset = true
	gui.ResetOnSpawn = false
	gui.Parent = pg

	local dip = Instance.new("Frame")
	dip.Name = "Dip"
	dip.Size = UDim2.fromScale(1, 1)
	dip.Position = UDim2.fromScale(0, 0)
	dip.BackgroundColor3 = Color3.new(0, 0, 0)
	dip.BackgroundTransparency = 1
	dip.BorderSizePixel = 0
	dip.ZIndex = 1
	dip.Parent = gui

	run.overlay = dip
	track(run, function()
		gui:Destroy()
	end)
	return dip
end

-- The angry read ends the moment the cut turns celebratory: eyes back to their
-- stored originals (calmEyes is idempotent) and the aura rim back to the rarity
-- colour -- which, for an EYELESS model, means undoing the red rim enterRise
-- painted in place of eyes (see enterEruption/enterRise). Called from EVERY path
-- that reaches the handoff frame: the hype beat, the handoff beat (the trimmed cut
-- has no hype) and forceHandoffState (a skip jumps straight over both).
local function calmAngry(run: Run)
	if run.brain then
		run.brain:calmEyes()
	end
	if run.model then
		local rim = run.model:FindFirstChild("CinematicAura")
		if rim and rim:IsA("Highlight") then
			rim.OutlineColor = run.rarityColor
		end
	end
end

-- ============================== beats ==============================

local function enterBonk(run: Run)
	if run.water then
		run.water:stillWater()
		run.water:bonkRing()
		-- the dark back the rock just clonked off -- sized from the creature so a
		-- bigger catch shows a bigger back
		local ext = run.extents :: Vector3
		run.water:bonkHump(math.max(ext.X, ext.Z) * 0.28)
	end
	if run.audio then
		run.audio:play("bonkClonk", { where = run.surface })
		if not run.spectator then
			run.audio:duckAmbient(0.35, 0.25 * run.stretch)
		end
	end
	if run.shake then
		run.shake:add(0.55)
	end
	if run.cam then
		local c = Config.CAMERA
		run.cam:punchFOV(c.fovPunchHi or 95, c.fovPunchSettle or 78, (c.fovPunchDur or 0.5) * run.stretch)
	end
end

local function enterTravel(run: Run)
	if run.cam then
		local c = Config.CAMERA
		local eye = run.surface
			- run.horiz * TRAVEL_BACK_STUDS
			+ Vector3.new(0, c.outboundHeight or 6, 0)
		run.travelEye = eye
		local seconds = (run.beats[run.beatIdx].t1 - run.beats[run.beatIdx].t0) * run.stretch
		run.cam:flyTo(CFrame.lookAt(eye, run.surface), seconds, true)
	end
	-- The suspense build moved to enterDread (owner's Jaws note, 2026-08-09): the
	-- travel is wind and water only, and the 4.0s build starts WITH the rings so its
	-- peak lands exactly where the silence guillotines it.
end

local function enterDread(run: Run)
	if run.audio then
		-- speed = run.speed: the 4.0s build has to hard-stop at the SILENCE in
		-- cinematic time, so a debug timescale PITCHES the clip rather than letting a
		-- 1x-length rumble bleed straight over the eruption. speed 1 is unchanged.
		run.audio:play("rumbleLoop", { where = run.surface, speed = run.speed })
	end
	if run.cam then
		local eye = run.travelEye or (run.surface - run.horiz * TRAVEL_BACK_STUDS + Vector3.new(0, 6, 0))
		run.cam:lookHover(eye, run.surface)
	end
end

local function updateDread(run: Run, p: number)
	if run.water then
		run.water:rippleTrain(p)
		run.water:suctionAndShadow(p)
		if not run.domeUp and p >= 0.72 then
			run.domeUp = true
			local ext = run.extents :: Vector3
			run.water:dome(math.max(math.max(ext.X, ext.Z) * 0.55, 2))
		end
	end
	if run.shake then
		run.shake:setSustain((Config.SHAKE.dreadRampTo or 0.4) * p)
	end
end

local function enterSilence(run: Run)
	if run.shake then
		run.shake:setSustain(0)
	end
	-- Dead air is the beat. Spectators keep their own world audio -- silencing a
	-- bystander's entire game for someone else's catch is not ours to do.
	if run.audio and not run.spectator then
		run.audio:silence()
	end
end

local function exitSilence(run: Run)
	if run.audio and not run.spectator then
		run.audio:unsilence()
	end
end

local function enterEruption(run: Run)
	if run.audio then
		run.audio:unsilence()
	end
	if run.water then
		run.water:burstDome()
		run.water:erupt(run.extents)
	end
	if run.brain then
		-- NO MORE FROZEN POSE (owner: "why does it pause"): the eruption beat now
		-- DRIVES the emergence -- updateEruption walks setRise 0 -> breachAlpha, and
		-- the rise beat continues breachAlpha -> 1, so from the moment the dome
		-- bursts the creature never stops moving.
		-- FACING: the rise's slow turn (0.6*pi in setRise) must LAND square on the
		-- camera, so the base yaw is aimed-at-camera MINUS the turn still to come.
		if run.heroEye == nil and run.cam then
			local eye, focus = heroFraming(run)
			run.heroEye, run.heroFocus = eye, focus
		end
		local aim = (run.heroEye or (run.surface + run.horiz * -40)) - run.surface
		local facingYaw = math.atan2(aim.X, aim.Z)
		run.brain:setFacing(facingYaw - math.pi * 0.6)
		-- FALSE means this model has no eye parts at all -- 170 of the 191 models in
		-- BrainrotModels don't have one, so the owner's angry face never showed on most
		-- catches (their own demo Kraken included). enterRise reddens the AURA RIM
		-- instead when that happens: the angry read the eyes could not give.
		run.eyesApplied = run.brain:angryEyes()
		-- The eruption IS the breach now that nothing calls breachPose: past here a
		-- reveal-time swapModel must refuse, or it would rebuild the creature
		-- mid-emergence. run.breached is this module's copy of the same fact.
		run.brain:markBreached()
		run.breached = true
	end
	if run.post then
		run.post:flash()
	end
	if run.audio then
		run.audio:play("bassDrop", { where = run.surface })
		run.audio:play("waterExplosion", { where = run.surface })
		run.audio:play("roar", { where = run.surface })
	end
	if run.shake then
		run.shake:add(Config.SHAKE.eruption or 1.0)
	end
	if run.cam then
		local c = Config.CAMERA
		run.cam:punchFOV(c.fovPunchHi or 95, c.fovBase or 70, 0.45 * run.stretch)
		local eye, focus = heroFraming(run)
		run.heroEye, run.heroFocus = eye, focus
		run.cam:lookHover(eye, focus)
	end
end

local function enterRise(run: Run)
	local beat = run.beats[run.beatIdx]
	if run.brain then
		run.brain:revealColors(0.6 * run.stretch)
	end
	if run.water then
		if run.model then
			-- Already timescaled: waterCfg is the scaled copy (see scaleDurations).
			run.water:cascade(run.model, run.waterCfg.cascadeSeconds or 2.0)
		end
		run.water:godrays(run.surface, (run.extents :: Vector3).Y * 1.4)
	end
	-- THE AURA (owner: "like someone aurafarming getting out of the pool"): a
	-- rarity-coloured rim on the creature for the whole rise. Parented to the model
	-- inside the stage, so every teardown path already destroys it.
	if run.model then
		pcall(function()
			local rim = Instance.new("Highlight")
			rim.Name = "CinematicAura"
			rim.FillTransparency = 1
			-- RED when there were no eye parts to redden (see enterEruption). The owner
			-- asked for an angry face and most models cannot show one, so the rim carries
			-- the anger instead. calmAngry() puts it back to the rarity colour for the
			-- hype/handoff, so the celebratory frame is identical either way.
			rim.OutlineColor = run.eyesApplied and run.rarityColor or Color3.fromRGB(255, 45, 25)
			rim.OutlineTransparency = 0.25
			rim.DepthMode = Enum.HighlightDepthMode.Occluded
			rim.Parent = run.model
		end)
	end
	-- heroEye/heroFocus for the hype beat's zoom punches, which pull in along this
	-- eye->focus line. NO flyTo here any more: the orbit() a few lines down overwrites
	-- CameraRig's single motion slot in the same frame, before anything renders, so
	-- the fly was dead the instant it was set (removal verified bit-identical).
	if run.cam then
		local eye, focus = heroFraming(run)
		run.heroEye, run.heroFocus = eye, focus
	end
	if run.shake then
		run.shake:setSustain(Config.SHAKE.riseSustain or 0.35)
	end
	if run.cam then
		local c = Config.CAMERA
		local ext = run.extents :: Vector3
		local _, focus = heroFraming(run)
		local dist = math.max(ext.X, ext.Z) * (c.heroDistMult or 0.95) + VIEW_DIST_PAD
		run.cam:orbit(focus, c.orbitDegrees or 45, (beat.t1 - beat.t0) * run.stretch, dist, ext.Y * (c.heroHeightFrac or 0.18))
	end
end

local function updateRise(run: Run, p: number)
	if run.brain and not run.skipping then
		-- Continue FROM the breach pose rather than restarting at 0 -- eruption left
		-- the creature's head above the surface, and re-posing from alpha 0 dunked it
		-- back underwater for the first stretch of the beat (owner-visible glitch).
		local a0 = run.brain:breachAlpha()
		run.brain:setRise(a0 + p * (1 - a0))
	end
end

local function enterHype(run: Run)
	if run.post then
		run.post:hypeOn(0.5 * run.stretch)
	end
	calmAngry(run)
	if run.hype then
		run.hype:banner("MAX BRAINROT", run.rarityColor)
		run.hype:nameText(run.displayName)
		run.hype:confetti()
		run.hype:speedLines()
	end
	-- memeAudio is the catcher's screen-space heel-turn track, paired with a banner
	-- and confetti a spectator never sees. Playing it at them across the lake would be
	-- someone else's meme music with no picture attached, so spectators simply do not
	-- get this slot -- the world FX (eruption, cascade, roar) still carry the moment.
	if run.audio and not run.spectator then
		run.audio:play("memeAudio")
	end
	if run.cam then
		local eye, focus = heroFraming(run)
		run.heroEye, run.heroFocus = eye, focus
		run.cam:lookHover(eye, focus)
	end
end

local function updateHype(run: Run, _p: number)
	if run.hype then
		-- Pure in t, and t is ALREADY timescaled at the source (see the header).
		run.hype:memeFlyIns(run.t)
	end
	local times = Config.HYPE.zoomPunchTimes or {}
	for i, punchT in ipairs(times) do
		if not run.punchFired[i] and run.t >= punchT then
			run.punchFired[i] = true
			run.punchUntil = run.t + PUNCH_HOLD
			if run.shake then
				run.shake:add(0.25)
			end
		end
	end
	if run.cam and run.heroEye then
		local pulled = run.punchUntil ~= nil and run.t < run.punchUntil
		if pulled ~= run.punchState then
			run.punchState = pulled
			local focus = run.heroFocus :: Vector3
			local eye = run.heroEye :: Vector3
			if pulled then
				local scale = Config.CAMERA.zoomPunchScale or 0.86
				eye = focus + (eye - focus) * scale
			end
			run.cam:lookHover(eye, focus)
		end
	end
end

local function enterHandoff(run: Run)
	-- The TRIMMED cut has no hype beat, so this is where its angry read gets undone;
	-- for the full cut enterHype already did it and this is an idempotent no-op.
	calmAngry(run)
	if run.shake then
		run.shake:setSustain(0)
	end
	if run.hype then
		run.hype:hideSkipPrompt()
	end
	if run.post then
		-- postCfg is the scaled copy; easeBackSeconds is already timescaled.
		run.post:easeBack(run.postCfg.easeBackSeconds or 1.2)
	end
	if run.audio then
		-- 2D for the catcher (it is their card arriving), positional at the lake for a
		-- spectator, where it reads as the creature being whisked away out there.
		run.audio:play("cardWhoosh", run.spectator and { where = run.surface } or nil)
		run.audio:restoreAmbient(0.6 * run.stretch)
	end

	local beat = run.beats[run.beatIdx]
	local seconds = (beat.t1 - beat.t0) * 0.42 * run.stretch

	if run.spectator then
		-- A bystander's creature does not fly into THEIR bag. It sinks back under,
		-- driven by updateHandoff; nothing else in this beat applies to them.
		return
	end

	if run.brain then
		-- UNIT CONVERSION, deliberate: HypeUI.bagTarget() returns absolute PIXELS,
		-- BrainrotRig.compressAndStreak() wants a 0..1 viewport FRACTION. Neither
		-- module is wrong on its own; the seam between them is this line.
		local target = Vector2.new(0.86, 0.92)
		if run.hype then
			local px = run.hype:bagTarget()
			local cam = Workspace.CurrentCamera
			local vs = cam and cam.ViewportSize or Vector2.new(1280, 720)
			if vs.X > 0 and vs.Y > 0 then
				target = Vector2.new(
					math.clamp(px.X / vs.X, 0, 1),
					math.clamp(px.Y / vs.Y, 0, 1)
				)
			end
		end
		run.brain:compressAndStreak(target, seconds, function()
			if run.hype then
				run.hype:cardArrive(run.rarityColor)
			end
		end)
	end

	if run.cam then
		run.cam:returnToPlayer((Config.CAMERA.returnBlendSeconds or 0.8) * run.stretch, nil)
	end
end

local function updateHandoff(run: Run, p: number)
	if run.spectator and run.brain then
		run.brain:setRise(1 - p)
	end
end

local ENTER: { [string]: (Run) -> () } = {
	bonk = enterBonk,
	travel = enterTravel,
	dread = enterDread,
	silence = enterSilence,
	eruption = enterEruption,
	rise = enterRise,
	hype = enterHype,
	handoff = enterHandoff,
}

local function updateEruption(run: Run, p: number)
	if run.brain and not run.skipping then
		run.brain:setRise(p * run.brain:breachAlpha())
	end
end

local UPDATE: { [string]: (Run, number) -> () } = {
	dread = updateDread,
	eruption = updateEruption,
	rise = updateRise,
	hype = updateHype,
	handoff = updateHandoff,
}

local EXIT: { [string]: (Run) -> () } = {
	silence = exitSilence,
}

-- ============================== finish ==============================

local function finish(run: Run, ok: boolean)
	if run.finished then
		return
	end
	run.finished = true
	run.ok = ok
	drain(run)
	if active == run then
		active = nil
	end
	-- Fired LAST and only for the thrower: this is what releases CatchRevealClient's
	-- deferred ordinary chain (or reruns it wholesale when ok is false). Passed with
	-- OUR generation, so a run that was superseded by a later throw's arm cannot
	-- settle that arm on its way out. Bridge task.spawns each callback, so a blocking
	-- PullCeremony can never stall a caller of finish() -- sometimes the render step.
	if run.usesBridge then
		pcall(Bridge.finish, run.bridgeGen, ok)
	end
end

-- ============================== skip ==============================

local function forceHandoffState(run: Run)
	-- Everything the skipped beats would have left behind, set directly. Never a
	-- hard cut: this runs under the darkest frame of the luminance dip.
	if run.hype then
		run.hype:interrupt()
		run.hype:hideSkipPrompt()
	end
	if run.water then
		-- WaterFX has one teardown, and "calm water" IS its teardown: rings, dome,
		-- shadow, dip, column, godrays destroyed and Terrain's wave props restored.
		run.water:cleanup()
	end
	-- A skip must not land the player on a frame that still has the red eyes / red
	-- rim on it: undo the angry read BEFORE the reveal lerp captures its start
	-- colours (the skipped beats are exactly the ones that would have done it).
	calmAngry(run)
	if run.brain then
		run.brain:setRise(1)
		run.brain:revealColors(0.05)
		run.breached = true
	end
	if run.shake then
		run.shake:setSustain(0)
	end
	if run.audio then
		run.audio:unsilence()
	end
	if run.post then
		run.post:easeBack(0.2)
	end
	-- The joke landed or it didn't: a skipped run must not fire the second bonk's
	-- plink at the handoff, seconds after the rock was supposed to hit them.
	run.plinked = true
end

local function jumpToHandoff(run: Run)
	-- Defence in depth behind the conductor's gate: the ONE thing this function must
	-- never do is surface a creature whose grant has not been confirmed. FIRST, ahead of
	-- the missing-handoff branch below -- that branch reports SUCCESS, and a beat table
	-- without a handoff must never settle ok=true on a grant that never arrived.
	if run.usesBridge and not run.resultSeen then
		warn("[Sequencer] jumpToHandoff refused: no ThrowResult yet")
		return
	end
	local hi = beatIndexOf(run, "handoff")
	if not hi then
		finish(run, true)
		return
	end
	local current = run.beats[run.beatIdx]
	if current then
		local ex = EXIT[current.name]
		if ex then
			ex(run)
		end
	end
	forceHandoffState(run)
	-- Mark every intermediate beat as consumed WITHOUT running it: the dispatch
	-- loop below simply resumes at handoff.
	run.beatIdx = hi - 1
	run.t = run.beats[hi].t0
end

local function beginSkip(run: Run)
	if run.skipping or run.cancelling or run.finished then
		return
	end
	if run.spectator then
		-- There is nothing for a bystander to skip TO: no camera takeover, no hype, no
		-- handoff of their own. "Skip" here means "stop rendering someone else's
		-- weather", so it goes straight to teardown -- no fade, no camera work.
		run.skipping = true
		finish(run, true)
		return
	end
	run.skipping = true
	run.skipPhase = "out"
	run.skipClock = 0
	if run.hype then
		run.hype:interrupt()
		run.hype:hideSkipPrompt()
	end
	ensureOverlay(run)
end

local function inputQualifies(input: InputObject, spectator: boolean): boolean
	local t = input.UserInputType
	if t == Enum.UserInputType.Keyboard then
		if spectator and SPECTATOR_SKIP_IGNORED[input.KeyCode] then
			return false
		end
		return true
	end
	if t == Enum.UserInputType.Touch then
		-- SPECTATORS GET NO TOUCH-SKIP. On mobile the only sustained touch during someone
		-- else's catch is a camera drag, and half a second of that would silently delete
		-- their world FX. The thrower keeps it (their camera is hijacked, so a held touch
		-- IS deliberate, and they have a HOLD TO SKIP prompt telling them so). A spectator
		-- has no prompt, so there is no affordance being taken away -- and their FX end on
		-- their own in 10.7s. If mobile spectators ever get a visible prompt, the follow-up
		-- is a tap-and-hold with a movement threshold (disqualify past ~12px of drag),
		-- not simply re-enabling this.
		return not spectator
	end
	if t == Enum.UserInputType.Gamepad1 and input.KeyCode == Enum.KeyCode.ButtonB then
		return true
	end
	return false
end

local function wireSkipInput(run: Run)
	local holds: { [InputObject]: boolean } = {}
	local function recompute()
		run.holdDown = next(holds) ~= nil
	end
	local c1 = UserInputService.InputBegan:Connect(function(input, gpe)
		if gpe or not inputQualifies(input, run.spectator) then
			return
		end
		holds[input] = true
		recompute()
	end)
	local c2 = UserInputService.InputEnded:Connect(function(input)
		if holds[input] then
			holds[input] = nil
			recompute()
		end
	end)
	-- Alt-tabbing away eats the InputEnded for whatever was held, which would leave
	-- holdDown latched true and skip the cinematic the moment the window comes back.
	local c3 = UserInputService.WindowFocusReleased:Connect(function()
		table.clear(holds)
		run.holdDown = false
		run.holdTime = 0
	end)
	track(run, function()
		c1:Disconnect()
		c2:Disconnect()
		c3:Disconnect()
	end)
end

-- ============================== cancel ==============================

-- revealCatch can grant NOTHING (the player left mid-flight; a vaulted/unique/
-- limited fallback pool came up empty), in which case ThrowResult never fires. The
-- timeline must never show a creature the player does not own, so it winds down
-- here instead: a quick dip, the stock landing sound, camera home, run ends false.
local function beginCancel(run: Run)
	if run.cancelling or run.finished then
		return
	end
	run.cancelling = true
	run.skipping = false
	warn("[Sequencer] no ThrowResult within " .. tostring(Config.CANCEL_TIMEOUT) .. "s -- cancelling")

	if run.hype then
		run.hype:interrupt()
		run.hype:hideSkipPrompt()
	end
	if run.water then
		run.water:cleanup()
	end
	if run.brain then
		run.brain:cleanup()
		run.brain = nil
	end
	if run.rock then
		run.rock:cleanup()
		run.rock = nil
	end
	if run.shake then
		run.shake:setSustain(0)
	end
	if run.post then
		run.post:easeBack(0.25)
	end
	if run.audio then
		run.audio:unsilence()
		run.audio:play("waterExplosion", { where = run.surface })
		run.audio:restoreAmbient(0.35)
	end

	-- Dip continuity: a cancel can land while a skip's dip is already partway down (or
	-- parked at full dark waiting for the grant). Starting cancelClock at 0 would snap
	-- the screen back to clear and re-dip it. Seed the clock from the alpha already on
	-- screen so the cancel's ramp simply continues from wherever the skip left it.
	local dip0 = ensureOverlay(run)
	local alpha0 = dip0 and math.clamp((1 - dip0.BackgroundTransparency) / DIP_MAX, 0, 1) or 0
	run.cancelClock = alpha0 * CANCEL_DIP_IN
	run.cancelDeadline = CANCEL_DIP_IN + CANCEL_DIP_OUT + 0.5
	if run.cam then
		run.cam:returnToPlayer((Config.CAMERA.returnBlendSeconds or 0.8) * 0.7, function()
			finish(run, false)
		end)
	end
end

-- ============================== conductor ==============================

local function stepInner(run: Run, dt: number)
	run.realElapsed += dt

	-- (0) watchdog: a stalled beat must never leave the camera hijacked forever.
	if run.realElapsed > run.budget then
		warn("[Sequencer] watchdog fired at " .. string.format("%.2f", run.realElapsed) .. "s")
		finish(run, false)
		return
	end

	-- (1) master clock. The one place `t` ever advances.
	local newT = run.t + dt * run.speed

	-- Pre-eruption result hold: never breach the water for a creature the grant
	-- has not confirmed yet. Parks the clock a hair short of the eruption beat
	-- until either the result lands or the cancel deadline does.
	if not run.spectator and not run.resultSeen and not run.cancelling then
		if newT >= run.eruptionT0 and run.realElapsed < run.cancelTimeout then
			newT = math.min(newT, run.eruptionT0 - 1e-3)
		end
	end
	run.t = newT

	-- (2) cancel deadline
	if not run.spectator and not run.resultSeen and not run.cancelling then
		if run.realElapsed >= run.cancelTimeout then
			beginCancel(run)
		end
	end
	if run.cancelling then
		run.cancelClock += dt
		local dip = run.overlay
		if dip then
			local a: number
			if run.cancelClock <= CANCEL_DIP_IN then
				a = run.cancelClock / CANCEL_DIP_IN
			else
				a = math.clamp(1 - (run.cancelClock - CANCEL_DIP_IN) / CANCEL_DIP_OUT, 0, 1)
			end
			dip.BackgroundTransparency = 1 - a * DIP_MAX
		end
		if run.cancelClock >= run.cancelDeadline then
			finish(run, false)
		end
		return
	end

	-- (3) ThrowResult reconciliation. The server's roll can be superseded at reveal
	-- time (obtainability re-roll, limited-stock swap), and swapModel is refused
	-- once breachPose has run -- so this has to happen before the eruption beat.
	if run.usesBridge and not run.resultSeen then
		local res = Bridge.result(run.bridgeGen)
		if res ~= nil then
			run.resultSeen = true
			run.result = res
			local name = res.BrainrotName
			if type(name) == "string" and name ~= "" and name ~= run.name and not run.breached and run.brain then
				if run.brain:swapModel(name) then
					run.name = name
					refreshGeometry(run)
					run.displayName = Sizes.Label(res.Mutation or run.payload.Mutation, run.size, name)
				end
			end
		end
	end

	-- (4) skip: prompt, hold poll, luminance dip. Spectators arm too (item 7: they can
	-- stop rendering someone else's weather) but get no prompt -- they have no HypeUI,
	-- and a prompt for a cutscene that is not addressed to them would be noise.
	if not run.skipArmed and run.t >= run.skipDelay then
		run.skipArmed = true
		if run.hype then
			run.hype:showSkipPrompt()
		end
	end
	if run.skipArmed and not run.skipping then
		if run.holdDown then
			run.holdTime += dt
		else
			run.holdTime = 0
		end
		local a = math.clamp(run.holdTime / run.skipHold, 0, 1)
		if run.hype then
			run.hype:setSkipProgress(a)
		end
		if a >= 1 then
			beginSkip(run)
		end
	end
	if run.skipping and run.skipPhase ~= "done" then
		run.skipClock += dt
		local half = math.max(run.skipFade * 0.5, 0.02)
		local dip = run.overlay
		local a = math.clamp(run.skipClock / half, 0, 1)
		if run.skipPhase == "out" then
			if dip then
				dip.BackgroundTransparency = 1 - a * DIP_MAX
			end
			if a >= 1 then
				-- THE GATE. jumpToHandoff surfaces, reveals and then streaks the
				-- creature into the player's bag -- it must never run for a grant that
				-- has not landed, or a skip would show and award the very catch the
				-- cancel path exists to prevent, and cancel would then delete it
				-- mid-streak. So the dip simply HOLDS at full dark until the result
				-- arrives. The wait is milliseconds in any realistic case, and if the
				-- grant never comes at all, beginCancel takes over from an
				-- already-dark screen -- exactly the continuity it wants. `a` is
				-- clamped at 1, so this re-tests every frame.
				if run.usesBridge and not run.resultSeen then
					run.skipHolding = true
				else
					run.skipHolding = false
					jumpToHandoff(run)
					run.skipPhase = "in"
					run.skipClock = 0
				end
			end
		else
			if dip then
				dip.BackgroundTransparency = 1 - (1 - a) * DIP_MAX
			end
			if a >= 1 then
				run.skipPhase = "done"
				if dip then
					dip.BackgroundTransparency = 1
				end
			end
		end
	end

	-- A spectator's skip finishes the run SYNCHRONOUSLY inside the block above (there is
	-- nothing to fade to), and jumpToHandoff can finish too if the beat table has no
	-- handoff. Either way the trove is already drained: the stage is destroyed and the
	-- rigs cleaned. Everything below would then run one partial frame against dead state
	-- -- and WaterFX guards only 2 of its 15 methods on _destroyed, so a dread- or
	-- rise-beat update would parent brand-new parts into a destroyed stage. Bail out.
	if run.finished then
		return
	end

	-- (5) the rock, pure in t, every frame from the bonk onward
	if run.rock then
		local head: Vector3? = nil
		if run.brain then
			head = run.brain:headTop()
		end
		run.rock:update(run.t, head)
	end

	-- (6) the second bonk one-shot (the joke: it comes back down on their head)
	if not run.plinked and run.t >= run.secondBonkT then
		run.plinked = true
		if run.audio then
			local where = run.brain and run.brain:headTop() or run.surface
			run.audio:play("plink", { where = where })
		end
		if run.shake then
			run.shake:add(0.2)
		end
		if run.brain and not run.skipping then
			run.brain:eyeTwitch()
		end
	end

	-- (7) beat dispatch
	while run.beatIdx < #run.beats do
		local nextBeat = run.beats[run.beatIdx + 1]
		if run.t < nextBeat.t0 then
			break
		end
		local current = run.beats[run.beatIdx]
		if current then
			local ex = EXIT[current.name]
			if ex then
				ex(run)
			end
		end
		run.beatIdx += 1
		local en = ENTER[nextBeat.name]
		if en then
			en(run)
		end
	end

	local beat = run.beats[run.beatIdx]
	if beat then
		local span = math.max(beat.t1 - beat.t0, 1e-3)
		local p = math.clamp((run.t - beat.t0) / span, 0, 1)
		local up = UPDATE[beat.name]
		if up then
			up(run, p)
		end
	end

	-- (8) end of timeline
	if run.t >= run.beats[#run.beats].t1 then
		finish(run, true)
	end
end

local function step(run: Run, dt: number)
	if run.finished then
		return
	end
	local ok, err = pcall(stepInner, run, dt)
	if not ok then
		warn("[Sequencer] beat error, tearing down: " .. tostring(err))
		finish(run, false)
	end
end

-- ============================== build ==============================

-- Builds every rig into a stage folder that is still parented to NIL, so a decline
-- (unknown creature model) can happen with literally nothing in the world yet.
-- Returns false to DECLINE; the caller stages its own stock landing instead.
local function buildRun(run: Run): boolean
	local stage = Instance.new("Folder")
	stage.Name = STAGE_NAME
	run.stage = stage
	track(run, function()
		stage:Destroy()
	end)

	local brain = BrainrotRig.new(stage, run.name, run.size, run.surface)
	if not brain then
		warn("[Sequencer] declining: no model for '" .. tostring(run.name) .. "'")
		return false
	end
	run.brain = brain
	track(run, function()
		brain:cleanup()
	end)
	refreshGeometry(run)

	local rock = RockRig.new(
		shallowMerge(Config.ROCK, rockTimings(run)),
		stage,
		run.payload.RockId,
		run.payload.RockColor,
		run.surface,
		run.rng
	)
	run.rock = rock
	track(run, function()
		rock:cleanup()
	end)

	local water = WaterFX.new(run.waterCfg, Config.PARTICLES, stage, run.surface, run.quality, run.rng)
	run.water = water
	track(run, function()
		water:cleanup()
	end)

	local audio = AudioBus.new(Config.ASSETS)
	run.audio = audio
	track(run, function()
		audio:cleanup()
	end)

	if not run.spectator then
		local cam = CameraRig.new(Config.CAMERA)
		if cam:takeover() then
			run.cam = cam
			track(run, function()
				cam:restore()
			end)
			-- HIDE THE GAME HUD for the takeover (owner: the rail/throw bar/toasts
			-- buried the creature). Everything re-enabled by the trove on EVERY exit
			-- path; our own gui (CatchCinematicUI, DisplayOrder 55) is never touched,
			-- and a gui that vanishes mid-cut is skipped by the pcall.
			do
				local pg = Players.LocalPlayer and Players.LocalPlayer:FindFirstChildOfClass("PlayerGui")
				if pg then
					local hidden = {}
					for _, g in ipairs(pg:GetChildren()) do
						if g:IsA("ScreenGui") and g.Enabled and g.Name ~= "CatchCinematicUI" and g.Name ~= "CatchCinematicFade" then
							g.Enabled = false
							table.insert(hidden, g)
						end
					end
					track(run, function()
						for _, g in ipairs(hidden) do
							pcall(function()
								g.Enabled = true
							end)
						end
					end)
				end
			end
			local shake = ScreenShake.new(shallowMerge(Config.SHAKE, {
				shakeMult = run.reducedMotion and (Config.REDUCED_MOTION.shakeMult or 0.25) or 1,
			}))
			run.shake = shake
			-- CameraRig calls the shake source with NO arguments (its own contract),
			-- but ScreenShake:sample needs a dt -- so the closure keeps its own wall
			-- clock. Real dt, deliberately: trauma decay is a physical falloff, not a
			-- beat, and it must decay at the same rate at any timescale.
			local lastSample = os.clock()
			cam:setShakeSource(function()
				local now = os.clock()
				local d = math.clamp(now - lastSample, 0, 0.1)
				lastSample = now
				return shake:sample(d)
			end)
		else
			-- Degrade, do not decline: the world half of the cinematic is still
			-- worth showing, and the stock fallback would double up on it.
			warn("[Sequencer] camera takeover refused -- running without the camera")
		end

		local post = PostFX.new(run.postCfg, run.quality, run.reducedMotion)
		run.post = post
		track(run, function()
			post:cleanup()
		end)

		local hype = HypeUI.new(
			{ HYPE = Config.HYPE, SKIP = Config.SKIP, PARTICLES = Config.PARTICLES },
			run.quality,
			run.reducedMotion,
			run.rng,
			run.stretch -- DURATION multiplier, see the TIMESCALE header
		)
		run.hype = hype
		track(run, function()
			hype:cleanup()
		end)
	end

	-- Wired for BOTH variants: the thrower skips into the handoff, a spectator skips
	-- straight to teardown (see beginSkip).
	wireSkipInput(run)

	stage.Parent = Workspace
	return true
end

local function wireKillSwitches(run: Run)
	local player = Players.LocalPlayer
	if not player then
		return
	end
	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if hum then
		local c = hum.Died:Connect(function()
			finish(run, false)
		end)
		track(run, function()
			c:Disconnect()
		end)
	end
	local ca = player.CharacterAdded:Connect(function()
		finish(run, false)
	end)
	track(run, function()
		ca:Disconnect()
	end)
end

-- ============================== public ==============================

function Sequencer.isActive(): boolean
	return active ~= nil
end

-- Test seam (Studio/harness only): the live run's clock and beat, read-only.
function Sequencer.debugState(): { [string]: any }?
	local run = active
	if not run then
		return nil
	end
	return {
		t = run.t,
		realElapsed = run.realElapsed,
		beat = run.beats[run.beatIdx] and run.beats[run.beatIdx].name or "pre",
		spectator = run.spectator,
		variant = run.variant,
		skipping = run.skipping,
		skipHolding = run.skipHolding,
		cancelling = run.cancelling,
		resultSeen = run.resultSeen,
		committed = run.committed,
		bridgeGen = run.bridgeGen,
	}
end

-- Test seam (Studio only): forces the skip-hold input state. A harness CANNOT press a
-- real key here -- VirtualInputManager refuses script-injected callers ("lacking
-- capability RobloxScript"), verified in this place -- so this replaces ONLY the two
-- UserInputService listeners in wireSkipInput and leaves the entire hold -> progress
-- bar -> luminance dip -> jumpToHandoff -> forceHandoffState -> handoff path under
-- test. No-op outside Studio and no-op with no run in flight.
function Sequencer.debugHold(down: boolean)
	if not RunService:IsStudio() then
		return
	end
	local run = active
	if run then
		run.holdDown = down == true
	end
end

function Sequencer.play(payload: { [string]: any }, opts: PlayOpts?): boolean
	-- Debounce FIRST: two rigs on one lake is the one failure that cannot be
	-- cleaned up after, so a second play never even inspects its payload.
	if active ~= nil then
		return false
	end
	if type(payload) ~= "table" then
		return false
	end
	if typeof(payload.EndPos) ~= "Vector3" then
		return false
	end
	if type(payload.BrainrotName) ~= "string" or payload.BrainrotName == "" then
		return false
	end
	if type(payload.Size) ~= "string" or payload.Size == "" then
		return false
	end

	local o = opts or {}
	local spectator = o.spectator == true
	local variant = o.variant
	if variant ~= "trimmed" then
		variant = "full"
	end
	local bridgeGen = o.bridgeGen
	-- Only a thrower run with a LIVE arm of its own talks to the Bridge. A superseded
	-- or expired generation means this throw's reveal already went back to the
	-- ordinary path, so this run must not poll for a result it will never own, and
	-- must not cancel on its absence.
	local usesBridge = (not spectator) and Bridge.isCurrent(bridgeGen)

	local player = Players.LocalPlayer
	if not player then
		return false
	end

	local speed = Config.timescale()
	if type(speed) ~= "number" or speed <= 0 then
		speed = 1
	end
	local stretch = 1 / speed

	local endPos = payload.EndPos :: Vector3
	local surfaceY = tonumber(payload.SurfaceY) or endPos.Y
	local surface = Vector3.new(endPos.X, surfaceY, endPos.Z)
	local beats = beatsFor(variant)

	local run: Run = {
		payload = payload,
		trove = {},
		cleaned = false,
		finished = false,
		ok = false,

		spectator = spectator,
		variant = variant,
		beats = beats,
		beatIdx = 0,
		t = 0,
		realElapsed = 0,
		speed = speed,
		stretch = stretch,
		budget = beats[#beats].t1 * stretch + WATCHDOG_PAD,

		surface = surface,
		horiz = horizToward(surface),
		name = payload.BrainrotName,
		size = payload.Size,
		rarityColor = (typeof(payload.RarityColor) == "Color3") and payload.RarityColor or Color3.fromRGB(255, 220, 120),
		rng = Random.new(tonumber(payload.Seed) or 1),
		quality = Config.qualityFor(player),
		reducedMotion = player:GetAttribute("CinematicReducedMotion") == true,

		waterCfg = scaleDurations(Config.WATER, WATER_DURATION_FIELDS, stretch),
		postCfg = scaleDurations(Config.POSTFX, POSTFX_DURATION_FIELDS, stretch),

		bridgeGen = bridgeGen,
		usesBridge = usesBridge,
		committed = false,
		-- Nothing to wait on unless this run owns a live arm: spectators never receive a
		-- ThrowResult, and a bridge-less thrower run's reveal is CatchRevealClient's.
		resultSeen = not usesBridge,
		breached = false,
		eyesApplied = false,
		plinked = false,
		domeUp = false,
		punchFired = {},
		punchState = false,

		skipArmed = false,
		skipping = false,
		skipPhase = "none",
		skipClock = 0,
		holdDown = false,
		holdTime = 0,
		skipDelay = Config.SKIP.delay or 1.0,
		skipHold = math.max(Config.SKIP.holdSeconds or 0.45, 0.05),
		skipFade = math.max(Config.SKIP.exitFadeSeconds or 0.18, 0.04),

		skipHolding = false,

		cancelling = false,
		cancelClock = 0,
		cancelDeadline = CANCEL_DIP_IN + CANCEL_DIP_OUT + 0.5,
		-- Scaled: see the TIMESCALE header. The deadline guards a position in the
		-- TIMELINE ("do not reach the eruption unresolved"), and the timeline stretches.
		cancelTimeout = math.max(tonumber(Config.CANCEL_TIMEOUT) or 3.0, 0.25) * stretch,
	}
	run.displayName = Sizes.Label(payload.Mutation, run.size, run.name)
	run.eruptionT0 = beatT0(run, "eruption", beats[#beats].t1)
	run.secondBonkT = rockTimings(run).secondBonkT

	active = run

	local okBuild, buildResult = pcall(buildRun, run)
	if not okBuild then
		warn("[Sequencer] build errored: " .. tostring(buildResult))
		drain(run)
		active = nil
		return false
	end
	if buildResult ~= true then
		-- buildRun declined (no model for this creature). Nothing was ever parented
		-- into Workspace, so the caller's stock landing is still on time.
		drain(run)
		active = nil
		return false
	end

	if run.usesBridge then
		-- Hand the Bridge our wall-clock budget so the arm outlives the cinematic --
		-- an arm that expires mid-run would hand the reveal back to the ordinary path
		-- on top of the cutscene still playing it.
		pcall(Bridge.markRunning, run.bridgeGen, run.budget + 4)
	end
	wireKillSwitches(run)

	runCounter += 1
	run.bindName = BIND_NAME .. VM_SALT .. "_" .. tostring(runCounter)
	local bindOk = pcall(function()
		RunService:BindToRenderStep(run.bindName, BIND_PRIORITY, function(dt: number)
			step(run, dt)
		end)
	end)
	if not bindOk then
		warn("[Sequencer] could not bind the conductor")
		drain(run)
		active = nil
		return false
	end
	track(run, function()
		pcall(function()
			RunService:UnbindFromRenderStep(run.bindName)
		end)
	end)

	-- Backstop watchdog. The in-conductor watchdog can only fire if the conductor is
	-- still being called -- and the failure it cannot cover is the render step itself
	-- stopping (unbound by something else, a render-thread stall, a Studio pause).
	-- Identity-guarded on `run`, so it can never kill a later run that reused the slot.
	task.delay(run.budget + 2, function()
		if active == run and not run.finished then
			warn("[Sequencer] backstop watchdog fired -- the conductor stopped being called")
			finish(run, false)
		end
	end)

	-- COMMITTED. Everything that can decline has already declined, and the next
	-- statement blocks. The caller observes this instead of inferring it from "play
	-- has not returned yet".
	run.committed = true
	if o.onCommit then
		pcall(o.onCommit)
	end

	-- BLOCKING from here. Every exit path funnels through finish(), which sets this
	-- flag, so there is no way out of this loop that skipped cleanup.
	while not run.finished do
		task.wait()
	end
	return true
end

return Sequencer
